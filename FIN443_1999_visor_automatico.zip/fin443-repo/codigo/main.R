# En RStudio: abre este archivo y pulsa Source.
# Desde la raiz del proyecto: Rscript codigo/main.R [datos/otra_base.csv]
local({
  source_paths <- lapply(rev(sys.frames()), function(frame) frame$ofile)
  source_paths <- Filter(Negate(is.null), source_paths)
  script_argument <- grep("^--file=", commandArgs(), value = TRUE)
  script <- if (length(source_paths)) {
    source_paths[[1L]]
  } else if (length(script_argument)) {
    sub("^--file=", "", script_argument[[1L]])
  } else {
    file.path("codigo", "main.R")
  }
  code_dir <- dirname(normalizePath(script, winslash = "/", mustWork = TRUE))
  root <- dirname(code_dir)

  args <- if (interactive()) character() else commandArgs(trailingOnly = TRUE)
  if (length(args) > 1L) stop("Uso: Rscript codigo/main.R [ruta_a_base_csv_o_xlsx]")
  input <- if (length(args)) args[[1L]] else file.path(root, "datos", "base_unidas.csv")
  out <- file.path(root, "resultados")

  source(file.path(code_dir, "analisis_fin443.R"), local = TRUE)
  source(file.path(code_dir, "visor_resultados.R"), local = TRUE)
  elapsed <- system.time({
    run_fin443(input = input, out = out, B = 1999L, seed = 443L)
    report <- write_results_viewer(out, code_dir)
  })
  message(sprintf("Tiempo total: %.2f minutos", elapsed[["elapsed"]] / 60))
  message("Hoja de resultados: ", report)
  open_results_viewer(report)
})
