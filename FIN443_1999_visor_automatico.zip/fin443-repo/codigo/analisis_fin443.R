# FIN443 | Contagio y comovimiento bursatil en America Latina
# Ejecutar desde la raiz con Rscript codigo/main.R.

find_fin443_input <- function() {
  candidates <- c(
    "datos/base_unidas.xlsx", "datos/bases_unidas.xlsx",
    "base_unidas.xlsx", "bases_unidas.xlsx",
    "datos/base_unidas.csv", "datos/bases_unidas.csv",
    "base_unidas.csv", "bases_unidas.csv"
  )
  found <- candidates[file.exists(candidates)]
  if (!length(found)) {
    stop("No se encontro la base de datos. Indique la ruta con run_fin443(input = ...).")
  }
  found[1L]
}

as_numeric_clean <- function(x) {
  if (is.numeric(x) && !inherits(x, c("Date", "POSIXt"))) {
    out <- as.double(x)
    out[!is.finite(out)] <- NA_real_
    return(out)
  }
  s <- trimws(as.character(x))
  na_tokens <- c("", "NA", "N/A", "#N/A", "#VALUE!", "#DIV/0!", "NULL", "null",
                 "NaN", "nan", ".", "-", "--", "nd", "ND", "s/d", "S/D")
  s[s %in% na_tokens] <- NA_character_
  has_comma <- grepl(",", s, fixed = TRUE)
  has_dot <- grepl(".", s, fixed = TRUE)
  both <- which(!is.na(s) & has_comma & has_dot)
  if (length(both)) {
    for (idx in both) {
      val <- s[idx]
      last_comma <- max(gregexpr(",", val, fixed = TRUE)[[1L]])
      last_dot <- max(gregexpr(".", val, fixed = TRUE)[[1L]])
      if (last_comma > last_dot) {
        s[idx] <- sub(",", ".", gsub(".", "", val, fixed = TRUE), fixed = TRUE)
      } else {
        s[idx] <- gsub(",", "", val, fixed = TRUE)
      }
    }
  }
  only_comma <- !is.na(s) & has_comma & !has_dot
  if (any(only_comma)) {
    s[only_comma] <- gsub(",", ".", s[only_comma], fixed = TRUE)
  }
  s <- gsub("[^0-9eE+\\.-]", "", s)
  out <- suppressWarnings(as.double(s))
  out[!is.finite(out)] <- NA_real_
  out
}

na_locf_vec <- function(y) {
  y <- as.double(y)
  ok <- is.finite(y)
  if (!any(ok)) return(rep(NA_real_, length(y)))
  idx <- cummax(ifelse(ok, seq_along(y), 0L))
  fill <- idx > 0L & !ok
  if (any(fill)) y[fill] <- y[idx[fill]]
  y
}

normalize_month_tokens <- function(s) {
  replacements <- c(
    "enero" = "01", "ene" = "01", "january" = "01", "jan" = "01",
    "febrero" = "02", "feb" = "02", "february" = "02",
    "marzo" = "03", "mar" = "03", "march" = "03",
    "abril" = "04", "abr" = "04", "april" = "04", "apr" = "04",
    "mayo" = "05", "may" = "05",
    "junio" = "06", "jun" = "06", "june" = "06",
    "julio" = "07", "jul" = "07", "july" = "07",
    "agosto" = "08", "ago" = "08", "august" = "08", "aug" = "08",
    "septiembre" = "09", "setiembre" = "09", "sep" = "09", "set" = "09",
    "september" = "09", "sept" = "09",
    "octubre" = "10", "oct" = "10", "october" = "10",
    "noviembre" = "11", "nov" = "11", "november" = "11",
    "diciembre" = "12", "dic" = "12", "december" = "12", "dec" = "12"
  )
  out <- tolower(s)
  out <- gsub("\\bde\\b", " ", out)
  for (nm in names(replacements)) {
    out <- gsub(paste0("\\b", nm, "\\b"), replacements[[nm]], out)
  }
  out
}

parse_fin443_dates <- function(raw) {
  if (inherits(raw, "Date")) {
    return(list(dates = raw, mode = "Date"))
  }
  if (inherits(raw, "POSIXt")) {
    return(list(dates = as.Date(as.POSIXct(raw), tz = "UTC"), mode = "POSIXt"))
  }
  if (is.numeric(raw)) {
    out <- rep(as.Date(NA), length(raw))
    ok <- is.finite(raw)
    if (any(ok)) {
      v <- raw[ok]
      is_ymd <- v >= 19000101 & v <= 21991231 & abs(v - round(v)) < 1e-6
      is_unix <- v > 1e8 & !is_ymd
      is_excel <- !is_ymd & !is_unix
      res <- rep(as.Date(NA), length(v))
      if (any(is_excel)) res[is_excel] <- as.Date(floor(v[is_excel]), origin = "1899-12-30")
      if (any(is_ymd)) res[is_ymd] <- as.Date(sprintf("%08.0f", v[is_ymd]), format = "%Y%m%d")
      if (any(is_unix)) {
        res[is_unix] <- as.Date(as.POSIXct(v[is_unix], origin = "1970-01-01", tz = "UTC"), tz = "UTC")
      }
      out[ok] <- res
    }
    return(list(dates = out, mode = "numeric_serial"))
  }

  s <- trimws(as.character(raw))
  s[s %in% c("", "NA", "N/A", "#N/A", "NULL", "null", "NaN", ".", "-")] <- NA_character_
  out <- rep(as.Date(NA), length(s))
  valid <- which(!is.na(s))
  if (!length(valid)) return(list(dates = out, mode = "empty"))

  sv <- s[valid]
  # 1. Numeros seriales de Excel o enteros YYYYMMDD guardados como texto
  is_num <- grepl("^-?[0-9]+(\\.[0-9]+)?$", sv)
  if (any(is_num)) {
    nv <- suppressWarnings(as.double(sv[is_num]))
    parsed_num <- rep(as.Date(NA), length(nv))
    ymd_idx <- is.finite(nv) & nv >= 19000101 & nv <= 21991231 & abs(nv - round(nv)) < 1e-6
    xl_idx <- is.finite(nv) & nv >= 10000 & nv <= 95000 & !ymd_idx
    unix_idx <- is.finite(nv) & nv > 1e8 & !ymd_idx
    if (any(ymd_idx)) parsed_num[ymd_idx] <- as.Date(sprintf("%08.0f", nv[ymd_idx]), format = "%Y%m%d")
    if (any(xl_idx)) parsed_num[xl_idx] <- as.Date(floor(nv[xl_idx]), origin = "1899-12-30")
    if (any(unix_idx)) {
      parsed_num[unix_idx] <- as.Date(as.POSIXct(nv[unix_idx], origin = "1970-01-01", tz = "UTC"), tz = "UTC")
    }
    out[valid[is_num]] <- parsed_num
  }

  rem <- which(is.na(out) & !is.na(s))
  if (length(rem)) {
    txt <- normalize_month_tokens(s[rem])
    # Quitar componente horario si viene "YYYY-MM-DD HH:MM:SS" o "DD/MM/YYYY 00:00"
    txt <- sub("[T ][0-9]{1,2}:[0-9]{2}(:[0-9]{2}(\\.[0-9]+)?)?.*$", "", trimws(txt))
    txt <- gsub("[/\\., ]+", "-", trimws(txt))
    txt <- gsub("-+", "-", txt)

    # 2. Formato ISO YYYY-MM-DD
    iso <- grepl("^[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}$", txt)
    if (any(iso)) {
      out[rem[iso]] <- suppressWarnings(as.Date(txt[iso], format = "%Y-%m-%d"))
    }

    # 3. Formatos AA-BB-YYYY o AA-BB-YY (resolver DMY vs MDY de forma inteligente)
    rem2_local <- which(!iso & grepl("^[0-9]{1,2}-[0-9]{1,2}-[0-9]{2,4}$", txt))
    if (length(rem2_local)) {
      parts <- do.call(rbind, strsplit(txt[rem2_local], "-", fixed = TRUE))
      p1 <- as.integer(parts[, 1L])
      p2 <- as.integer(parts[, 2L])
      yr <- as.integer(parts[, 3L])
      yr <- ifelse(yr < 100L, ifelse(yr <= 68L, 2000L + yr, 1900L + yr), yr)

      n_dmy_votes <- sum(p1 > 12L & p2 <= 12L, na.rm = TRUE)
      n_mdy_votes <- sum(p2 > 12L & p1 <= 12L, na.rm = TRUE)
      prefer_mdy <- n_mdy_votes > n_dmy_votes

      day <- ifelse(p1 > 12L & p2 <= 12L, p1,
             ifelse(p2 > 12L & p1 <= 12L, p2,
             if (prefer_mdy) p2 else p1))
      mon <- ifelse(p1 > 12L & p2 <= 12L, p2,
             ifelse(p2 > 12L & p1 <= 12L, p1,
             if (prefer_mdy) p1 else p2))

      built <- sprintf("%04d-%02d-%02d", yr, mon, day)
      out[rem[rem2_local]] <- suppressWarnings(as.Date(built, format = "%Y-%m-%d"))
    }
  }
  list(dates = out, mode = "character_mixed")
}

detect_excel_sheet <- function(path, sheet = NULL) {
  sheets <- readxl::excel_sheets(path)
  if (!is.null(sheet)) {
    if (is.numeric(sheet) && sheet >= 1 && sheet <= length(sheets)) return(sheets[sheet])
    idx <- match(tolower(trimws(sheet)), tolower(trimws(sheets)))
    if (!is.na(idx)) return(sheets[idx])
    stop("No se encontro la hoja '", sheet, "' en ", path)
  }
  idx_base <- match("base", tolower(trimws(sheets)))
  if (!is.na(idx_base)) return(sheets[idx_base])
  for (sh in sheets) {
    hdr <- tryCatch(names(readxl::read_excel(path, sheet = sh, n_max = 2L)),
                    error = function(e) character())
    has_date <- any(tolower(trimws(hdr)) %in% c("fecha", "fechas", "date", "dates", "timestamp", "dia"))
    has_mkt <- any(grepl("_(ret_usd|ret_local|precio_usd|precio_local|tc)$", hdr, ignore.case = TRUE))
    if (has_date && has_mkt) return(sh)
  }
  sheets[1L]
}

read_raw_table <- function(input, sheet = NULL) {
  if (is.data.frame(input)) {
    return(list(data = as.data.frame(input), source_label = "data.frame", sheet = NA_character_,
                md5 = NA_character_))
  }
  if (!is.character(input) || length(input) != 1L || !file.exists(input)) {
    stop("No se encuentra el archivo de entrada: ", input)
  }
  ext <- tolower(tools::file_ext(input))
  md5 <- unname(tools::md5sum(input))
  if (ext %in% c("csv", "txt", "tsv")) {
    first_line <- readLines(input, n = 1L, warn = FALSE)
    sep <- if (ext == "tsv" || grepl("\t", first_line)) {
      "\t"
    } else if (lengths(regmatches(first_line, gregexpr(";", first_line))) >
               lengths(regmatches(first_line, gregexpr(",", first_line)))) {
      ";"
    } else {
      ","
    }
    d <- utils::read.table(input, header = TRUE, sep = sep, quote = "\"",
                           check.names = FALSE, stringsAsFactors = FALSE,
                           comment.char = "", fill = TRUE)
    return(list(data = d, source_label = input, sheet = NA_character_, md5 = md5))
  }
  if (!requireNamespace("readxl", quietly = TRUE)) {
    stop("Instale la dependencia 'readxl' con install.packages('readxl').")
  }
  chosen_sheet <- detect_excel_sheet(input, sheet = sheet)
  d <- as.data.frame(readxl::read_excel(input, sheet = chosen_sheet, guess_max = 100000L))
  list(data = d, source_label = input, sheet = chosen_sheet, md5 = md5)
}

discover_markets <- function(col_names) {
  rx <- "^(.+)_(ret_usd|ret_local|precio_usd|precio_local|tc)$"
  matched <- grep(rx, col_names, value = TRUE)
  prefixes <- unique(sub(rx, "\\1", matched))
  prefixes <- setdiff(prefixes, c("SP500", "VIX", "US", "Global"))
  canonical <- c("Argentina", "Brasil", "Chile", "Colombia", "Mexico", "Peru")
  ordered <- c(intersect(canonical, prefixes), sort(setdiff(prefixes, canonical)))
  ordered
}

read_fin443 <- function(input = find_fin443_input(), sheet = NULL,
                        locf_method = c("niveles_y_locf", "locf_directo"),
                        date_range = NULL, min_obs = 300L) {
  locf_method <- match.arg(locf_method)
  raw_info <- read_raw_table(input, sheet = sheet)
  d <- raw_info$data
  names(d) <- trimws(names(d))
  n_raw_rows <- nrow(d)

  # Identificar columna de fecha de manera flexible
  date_candidates <- c("fecha", "fechas", "date", "dates", "timestamp", "dia", "period")
  date_idx <- which(tolower(names(d)) %in% date_candidates)
  if (!length(date_idx)) {
    stop("No se encontro columna de fecha (ej. 'fecha' o 'date').")
  }
  if (names(d)[date_idx[1L]] != "fecha") {
    names(d)[date_idx[1L]] <- "fecha"
  }

  parsed <- parse_fin443_dates(d$fecha)
  d$fecha <- parsed$dates
  n_invalid_dates <- sum(is.na(d$fecha))
  if (n_invalid_dates > 0L) {
    d <- d[!is.na(d$fecha), , drop = FALSE]
  }
  if (!nrow(d)) stop("Ninguna fecha valida pudo ser interpretada.")

  # Detectar desorden cronologico y ordenar preservando orden relativo en empates
  ord <- order(d$fecha, seq_len(nrow(d)))
  n_unsorted <- sum(ord != seq_len(nrow(d)))
  if (n_unsorted > 0L) {
    d <- d[ord, , drop = FALSE]
  }

  # Limpiar todas las columnas no-fecha a numerico
  num_cols <- setdiff(names(d), "fecha")
  for (cn in num_cols) {
    d[[cn]] <- as_numeric_clean(d[[cn]])
  }

  # Resolver fechas duplicadas conservando la ultima observacion finita de cada fecha
  n_duplicates <- sum(duplicated(d$fecha))
  if (n_duplicates > 0L) {
    split_idx <- split(seq_len(nrow(d)), d$fecha)
    dedup <- lapply(split_idx, function(rows) {
      if (length(rows) == 1L) return(d[rows, , drop = FALSE])
      out_row <- d[rows[length(rows)], , drop = FALSE]
      for (cn in num_cols) {
        vals <- d[[cn]][rows]
        ok <- which(is.finite(vals))
        out_row[[cn]] <- if (length(ok)) vals[ok[length(ok)]] else NA_real_
      }
      out_row
    })
    d <- do.call(rbind, dedup)
    rownames(d) <- NULL
  }

  if (!is.null(date_range)) {
    dr <- as.Date(date_range)
    if (length(dr) == 2L && !anyNA(dr)) {
      d <- d[d$fecha >= min(dr) & d$fecha <= max(dr), , drop = FALSE]
    }
  }

  markets <- discover_markets(names(d))
  if (length(markets) < 2L) {
    stop("Se requieren al menos 2 mercados con sufijos _ret_usd/_precio_usd/_precio_local/_tc.")
  }

  # Auditar NA originales antes de aplicar LOCF
  raw_snapshot <- d
  imputation_records <- list()
  record_imp <- function(col, raw_na, level_locf, price_recon, direct_locf, final_na) {
    imputation_records[[length(imputation_records) + 1L]] <<- data.frame(
      serie = col,
      na_originales = raw_na,
      imputados_locf_nivel = level_locf,
      reconstruidos_desde_nivel = price_recon,
      imputados_locf_directo = direct_locf,
      na_finales = final_na,
      stringsAsFactors = FALSE
    )
  }

  # 1) Sanitizar niveles positivos y reconciliar identidad P_usd = P_local / TC antes de LOCF
  level_patterns <- c(paste0(markets, "_precio_usd"), paste0(markets, "_precio_local"),
                      paste0(markets, "_tc"), "SP500_precio", "VIX")
  present_levels <- intersect(level_patterns, names(d))
  raw_level_na <- setNames(integer(length(present_levels)), present_levels)
  for (cn in present_levels) {
    bad <- is.finite(d[[cn]]) & d[[cn]] <= 0
    if (any(bad)) d[[cn]][bad] <- NA_real_
    raw_level_na[[cn]] <- sum(!is.finite(d[[cn]]))
  }

  for (m in markets) {
    pu <- paste0(m, "_precio_usd")
    pl <- paste0(m, "_precio_local")
    tc <- paste0(m, "_tc")
    has_pu <- pu %in% names(d)
    has_pl <- pl %in% names(d)
    has_tc <- tc %in% names(d)
    if (has_pl && has_tc && !has_pu) {
      d[[pu]] <- ifelse(is.finite(d[[pl]]) & is.finite(d[[tc]]) & d[[tc]] > 0,
                        d[[pl]] / d[[tc]], NA_real_)
      present_levels <- unique(c(present_levels, pu))
      raw_level_na[[pu]] <- sum(!is.finite(d[[pu]]))
    }
    if (has_pu && has_pl && has_tc) {
      miss_pu <- !is.finite(d[[pu]]) & is.finite(d[[pl]]) & is.finite(d[[tc]]) & d[[tc]] > 0
      if (any(miss_pu)) d[[pu]][miss_pu] <- d[[pl]][miss_pu] / d[[tc]][miss_pu]
      miss_pl <- !is.finite(d[[pl]]) & is.finite(d[[pu]]) & is.finite(d[[tc]])
      if (any(miss_pl)) d[[pl]][miss_pl] <- d[[pu]][miss_pl] * d[[tc]][miss_pl]
      miss_tc <- !is.finite(d[[tc]]) & is.finite(d[[pl]]) & is.finite(d[[pu]]) & d[[pu]] > 0
      if (any(miss_tc)) d[[tc]][miss_tc] <- d[[pl]][miss_tc] / d[[pu]][miss_tc]
    }
  }

  # 2) Aplicar LOCF a todas las series en niveles
  for (cn in present_levels) {
    before_na <- sum(!is.finite(d[[cn]]))
    d[[cn]] <- na_locf_vec(d[[cn]])
    after_na <- sum(!is.finite(d[[cn]]))
    record_imp(cn, raw_level_na[[cn]], before_na - after_na, 0L, 0L, after_na)
  }

  # Reconciliar posibles huecos iniciales tras LOCF
  for (m in markets) {
    pu <- paste0(m, "_precio_usd")
    pl <- paste0(m, "_precio_local")
    tc <- paste0(m, "_tc")
    if (all(c(pu, pl, tc) %in% names(d))) {
      miss_pu <- !is.finite(d[[pu]]) & is.finite(d[[pl]]) & is.finite(d[[tc]]) & d[[tc]] > 0
      if (any(miss_pu)) d[[pu]][miss_pu] <- d[[pl]][miss_pu] / d[[tc]][miss_pu]
    }
  }

  # 3) Construir/imputar retornos de mercados y factores con LOCF coherente
  fill_return_series <- function(ret_col, price_col = NULL) {
    y <- if (ret_col %in% names(d)) d[[ret_col]] else rep(NA_real_, nrow(d))
    raw_na <- sum(!is.finite(y))
    n_recon <- 0L
    if (locf_method == "niveles_y_locf" && !is.null(price_col) && price_col %in% names(d)) {
      p <- d[[price_col]]
      can_recon <- which(!is.finite(y) & seq_along(y) > 1L)
      if (length(can_recon)) {
        ok_p <- is.finite(p[can_recon]) & p[can_recon] > 0 &
                is.finite(p[can_recon - 1L]) & p[can_recon - 1L] > 0
        idx_r <- can_recon[ok_p]
        if (length(idx_r)) {
          y[idx_r] <- 100 * log(p[idx_r] / p[idx_r - 1L])
          n_recon <- length(idx_r)
        }
      }
    }
    before_direct <- sum(!is.finite(y))
    y <- na_locf_vec(y)
    after_direct <- sum(!is.finite(y))
    record_imp(ret_col, raw_na, 0L, n_recon, before_direct - after_direct, after_direct)
    y
  }

  for (m in markets) {
    ru <- paste0(m, "_ret_usd")
    rl <- paste0(m, "_ret_local")
    pu <- paste0(m, "_precio_usd")
    pl <- paste0(m, "_precio_local")
    tc <- paste0(m, "_tc")

    has_ru_or_pu <- (ru %in% names(d)) || (pu %in% names(d))
    has_rl_or_pl <- (rl %in% names(d)) || (pl %in% names(d))
    has_tc <- tc %in% names(d)

    if (has_ru_or_pu) d[[ru]] <- fill_return_series(ru, pu)
    if (has_rl_or_pl) d[[rl]] <- fill_return_series(rl, pl)

    # Si falta ret_usd pero existen ret_local y tc, o viceversa, completar por identidad cambiaria
    if (!(ru %in% names(d)) && (rl %in% names(d)) && has_tc) {
      fx_app <- c(0, -100 * diff(log(d[[tc]])))
      d[[ru]] <- na_locf_vec(d[[rl]] + fx_app)
      record_imp(ru, nrow(d), 0L, sum(is.finite(d[[ru]])), 0L, sum(!is.finite(d[[ru]])))
    }
    if (!(rl %in% names(d)) && (ru %in% names(d)) && has_tc) {
      fx_app <- c(0, -100 * diff(log(d[[tc]])))
      d[[rl]] <- na_locf_vec(d[[ru]] - fx_app)
      record_imp(rl, nrow(d), 0L, sum(is.finite(d[[rl]])), 0L, sum(!is.finite(d[[rl]])))
    }
    if (!(rl %in% names(d)) && (ru %in% names(d))) {
      d[[rl]] <- d[[ru]]
      record_imp(rl, nrow(d), 0L, nrow(d), 0L, sum(!is.finite(d[[rl]])))
    }
  }

  if (!("SP500_ret" %in% names(d)) && !("SP500_precio" %in% names(d))) {
    stop("Falta 'SP500_ret' (o 'SP500_precio' para reconstruirlo).")
  }
  if (!("VIX" %in% names(d))) {
    stop("Falta la columna 'VIX'.")
  }
  d$SP500_ret <- fill_return_series("SP500_ret", "SP500_precio")

  usd_cols <- paste0(markets, "_ret_usd")
  local_cols <- paste0(markets, "_ret_local")
  missing_req <- setdiff(c(usd_cols, local_cols, "SP500_ret", "VIX"), names(d))
  if (length(missing_req)) {
    stop("No fue posible construir las columnas requeridas: ", paste(missing_req, collapse = ", "))
  }

  # 4) Recortar unicamente filas iniciales previas a la primera observacion valida comun (pre-LOCF)
  core_mat <- as.matrix(d[c(usd_cols, local_cols, "SP500_ret", "VIX")])
  row_complete <- rowSums(!is.finite(core_mat)) == 0L & d$VIX > 0
  if (!any(row_complete)) {
    stop("No existen filas con observaciones simultaneamente validas tras LOCF.")
  }
  first_valid <- which(row_complete)[1L]
  n_trimmed_leading <- first_valid - 1L
  if (n_trimmed_leading > 0L) {
    d <- d[seq.int(first_valid, nrow(d)), , drop = FALSE]
    raw_snapshot <- raw_snapshot[seq.int(min(first_valid, nrow(raw_snapshot)), nrow(raw_snapshot)), , drop = FALSE]
    rownames(d) <- NULL
  }

  if (nrow(d) < min_obs) {
    stop("Muestra insuficiente (", nrow(d), " filas; minimo requerido = ", min_obs, ").")
  }

  x <- as.matrix(d[usd_cols])
  l <- as.matrix(d[local_cols])
  colnames(x) <- colnames(l) <- markets
  if (any(!is.finite(x)) || any(!is.finite(l))) {
    stop("Persisten valores no finitos inesperados tras LOCF.")
  }

  # 5) Retornos cambiarios (apreciacion de la moneda local frente al USD: s_t = -100 * dlog(TC_t))
  #    Se cumple exactamente: r_usd = r_local + s_t
  tc_cols <- paste0(markets, "_tc")
  has_all_tc <- all(tc_cols %in% names(d))
  fx <- NULL
  tc_mat <- NULL
  if (has_all_tc) {
    tc_mat <- as.matrix(d[tc_cols])
    colnames(tc_mat) <- markets
    if (all(is.finite(tc_mat)) && all(tc_mat > 0)) {
      fx <- matrix(NA_real_, nrow(d), length(markets), dimnames = list(NULL, markets))
      fx[1L, ] <- x[1L, ] - l[1L, ]
      if (nrow(d) > 1L) {
        fx[-1L, ] <- -100 * diff(log(tc_mat))
      }
      fx <- apply(fx, 2L, na_locf_vec)
    }
  }
  if (is.null(fx)) {
    # Respaldo exacto por identidad contable r_usd - r_local
    fx <- x - l
    colnames(fx) <- markets
  }

  log_vix <- log(d$VIX)
  dlog_vix <- c(NA_real_, 100 * diff(log_vix))
  if (locf_method == "locf_directo" && length(dlog_vix) > 1L && !is.finite(dlog_vix[1L])) {
    # Mantener convencion estandar de primera diferencia salvo que se pida relleno posterior
    dlog_vix[-1L] <- na_locf_vec(dlog_vix[-1L])
  }
  f <- cbind(SP500 = d$SP500_ret, dlogVIX = dlog_vix)
  vix_level <- d$VIX

  imp_df <- do.call(rbind, imputation_records)
  cleaning_summary <- data.frame(
    fuente = raw_info$source_label,
    hoja = ifelse(is.na(raw_info$sheet), "CSV/Tabla", raw_info$sheet),
    metodo_locf = locf_method,
    modo_fechas = parsed$mode,
    filas_brutas = n_raw_rows,
    fechas_invalidas_eliminadas = n_invalid_dates,
    filas_desordenadas_corregidas = n_unsorted,
    fechas_duplicadas_colapsadas = n_duplicates,
    filas_iniciales_recortadas_pre_locf = n_trimmed_leading,
    filas_finales = nrow(d),
    total_na_imputados = sum(imp_df$imputados_locf_nivel + imp_df$reconstruidos_desde_nivel +
                             imp_df$imputados_locf_directo),
    mercados_detectados = paste(markets, collapse = ", "),
    tiene_columnas_tc = has_all_tc,
    md5_base = ifelse(is.na(raw_info$md5), "", raw_info$md5),
    stringsAsFactors = FALSE
  )

  list(
    data = d,
    raw_snapshot = raw_snapshot,
    dates = d$fecha,
    markets = markets,
    usd = x,
    local = l,
    fx = fx,
    tc = tc_mat,
    factors = f,
    vix = vix_level,
    has_tc = has_all_tc,
    imputation = imp_df,
    cleaning = cleaning_summary
  )
}

audit_fin443 <- function(panel) {
  d <- panel$data
  fx_labeled <- panel$fx
  colnames(fx_labeled) <- paste0(colnames(panel$fx), "_fx_aprec_usd")
  x <- cbind(panel$usd, panel$local, fx_labeled, panel$factors, VIX_nivel = panel$vix)
  labels <- c(
    paste0(colnames(panel$usd), "_ret_usd"),
    paste0(colnames(panel$local), "_ret_local"),
    paste0(colnames(panel$fx), "_fx_aprec_usd"),
    colnames(panel$factors),
    "VIX"
  )
  imp_map <- setNames(
    panel$imputation$imputados_locf_nivel + panel$imputation$reconstruidos_desde_nivel +
      panel$imputation$imputados_locf_directo,
    panel$imputation$serie
  )
  na_orig_map <- setNames(panel$imputation$na_originales, panel$imputation$serie)

  series <- do.call(rbind, lapply(seq_len(ncol(x)), function(j) {
    y <- x[, j]
    lbl <- labels[j]
    ok <- which(is.finite(y))
    lo <- if (length(ok)) ok[which.min(y[ok])] else NA_integer_
    hi <- if (length(ok)) ok[which.max(y[ok])] else NA_integer_
    y_ok <- y[ok]
    m_val <- if (length(y_ok)) mean(y_ok) else NA_real_
    s_val <- if (length(y_ok) > 1L) stats::sd(y_ok) else NA_real_
    z_c <- if (is.finite(s_val) && s_val > 0) (y_ok - m_val) / s_val else rep(0, length(y_ok))
    skew <- if (length(z_c) > 2L) mean(z_c^3) else NA_real_
    kurt <- if (length(z_c) > 3L) mean(z_c^4) else NA_real_
    jb_stat <- if (is.finite(skew) && is.finite(kurt)) {
      length(y_ok) * (skew^2 / 6 + (kurt - 3)^2 / 24)
    } else {
      NA_real_
    }
    jb_p <- if (is.finite(jb_stat)) stats::pchisq(jb_stat, df = 2L, lower.tail = FALSE) else NA_real_
    lb_p <- if (length(y_ok) > 15L) stats::Box.test(y_ok, lag = 10L, type = "Ljung-Box")$p.value else NA_real_
    arch_p <- if (length(y_ok) > 15L) {
      stats::Box.test((y_ok - m_val)^2, lag = 10L, type = "Ljung-Box")$p.value
    } else {
      NA_real_
    }

    data.frame(
      serie = lbl,
      observaciones = length(ok),
      invalidas = sum(!is.finite(y)),
      na_originales = if (lbl %in% names(na_orig_map)) unname(na_orig_map[[lbl]]) else 0L,
      imputadas_locf = if (lbl %in% names(imp_map)) unname(imp_map[[lbl]]) else 0L,
      ceros = sum(y_ok == 0),
      media = m_val,
      desv_est = s_val,
      asimetria = skew,
      curtosis = kurt,
      p_JarqueBera = jb_p,
      p_LjungBox_10 = lb_p,
      p_ARCH_LjungBox_10 = arch_p,
      minimo = if (!is.na(lo)) y[lo] else NA_real_,
      fecha_minimo = if (!is.na(lo)) d$fecha[lo] else as.Date(NA),
      maximo = if (!is.na(hi)) y[hi] else NA_real_,
      fecha_maximo = if (!is.na(hi)) d$fecha[hi] else as.Date(NA),
      stringsAsFactors = FALSE
    )
  }))

  candidates <- c(
    setNames(paste0(colnames(panel$usd), "_precio_usd"), paste0(colnames(panel$usd), "_ret_usd")),
    setNames(paste0(colnames(panel$local), "_precio_local"), paste0(colnames(panel$local), "_ret_local")),
    SP500_ret = "SP500_precio"
  )
  price_list <- lapply(names(candidates), function(key) {
    p_col <- candidates[[key]]
    if (!(p_col %in% names(d)) || !(key %in% names(d))) return(NULL)
    p <- d[[p_col]]
    if (is.null(p) || !is.numeric(p)) return(NULL)
    ok <- is.finite(p) & p > 0
    i <- which(head(ok, -1L) & tail(ok, -1L)) + 1L
    i <- i[is.finite(d[[key]][i])]
    drift <- if (length(i)) abs(d[[key]][i] - 100 * log(p[i] / p[i - 1L])) else numeric()
    data.frame(
      serie = key,
      tramos = length(i),
      precio_invalido = sum(!ok),
      discrepancias = sum(drift > 1e-6),
      error_maximo = if (length(drift)) max(drift) else 0,
      stringsAsFactors = FALSE
    )
  })
  # Auditoria adicional de identidad cambiaria P_usd = P_local / TC
  fx_audit <- lapply(panel$markets, function(m) {
    pu <- d[[paste0(m, "_precio_usd")]]
    pl <- d[[paste0(m, "_precio_local")]]
    tc <- d[[paste0(m, "_tc")]]
    if (is.null(pu) || is.null(pl) || is.null(tc)) return(NULL)
    ok <- is.finite(pu) & is.finite(pl) & is.finite(tc) & pu > 0 & pl > 0 & tc > 0
    rel_err <- if (any(ok)) abs(pu[ok] - pl[ok] / tc[ok]) / pu[ok] else numeric()
    ret_err <- abs((panel$usd[, m] - panel$local[, m]) - panel$fx[, m])
    data.frame(
      serie = paste0(m, "_identidad_FX"),
      tramos = sum(ok),
      precio_invalido = sum(!ok),
      discrepancias = sum(rel_err > 1e-6) + sum(ret_err[-1L] > 1e-6),
      error_maximo = max(c(0, rel_err, ret_err[-1L]), na.rm = TRUE),
      stringsAsFactors = FALSE
    )
  })
  price <- do.call(rbind, c(price_list, fx_audit))
  list(series = series, prices = price, cleaning = panel$cleaning, imputation = panel$imputation)
}

default_crisis_catalog <- function() {
  data.frame(
    evento = c("Lehman", "Eurozona", "Taper", "China_Commodities",
               "Arg_PASO", "Estallido", "COVID", "Fed_2022", "Arg_Devaluacion"),
    fecha = as.Date(c("2008-09-15", "2011-08-05", "2013-05-22", "2015-08-11",
                      "2019-08-12", "2019-10-18", "2020-03-11", "2022-06-13", "2023-12-13")),
    tipo_shock = c("Global_Sorpresa", "Global_Soberano", "Global_Monetario", "Externo_Emergente",
                   "Idiosincratico_Pais", "Idiosincratico_Pais", "Global_Sorpresa",
                   "Global_Monetario", "Idiosincratico_FX"),
    mercado_origen = c("Ambas", "Ambas", "Ambas", "Ambas",
                       "Argentina", "Chile", "Ambas", "Ambas", "Argentina"),
    es_base_original = c(TRUE, FALSE, TRUE, FALSE, FALSE, TRUE, TRUE, FALSE, FALSE),
    stringsAsFactors = FALSE
  )
}

resolve_events <- function(dates, markets, usd_returns, n_pre = 120L, n_crisis = 60L,
                           custom_events = NULL) {
  cat_df <- if (is.null(custom_events)) default_crisis_catalog() else custom_events
  if (!("tipo_shock" %in% names(cat_df))) cat_df$tipo_shock <- "Episodio"
  if (!("mercado_origen" %in% names(cat_df))) cat_df$mercado_origen <- "Ambas"
  if (!("es_base_original" %in% names(cat_df))) cat_df$es_base_original <- TRUE

  # Si el mercado origen no existe en esta base (ej. sin Chile o sin Argentina), usar "Ambas"
  cat_df$mercado_origen <- ifelse(cat_df$mercado_origen %in% markets,
                                  cat_df$mercado_origen, "Ambas")

  valid_ev <- vapply(seq_len(nrow(cat_df)), function(i) {
    anch <- cat_df$fecha[i]
    sum(dates < anch) >= n_pre && sum(dates >= anch) >= n_crisis
  }, logical(1L))
  out <- cat_df[valid_ev, , drop = FALSE]

  # Si la base cubre otro periodo historico donde ningun episodio predefinido cae dentro,
  # detectar automaticamente hasta 4 episodios de estres de volatilidad regional sin traslape.
  if (!nrow(out)) {
    cs_vol <- sqrt(rowMeans(usd_returns^2))
    roll_v <- as.numeric(stats::filter(cs_vol, rep(1 / 20, 20), sides = 1L))
    candidates <- seq.int(n_pre + 1L, nrow(usd_returns) - n_crisis)
    picked <- integer()
    scores <- roll_v[candidates]
    ord <- candidates[order(scores, decreasing = TRUE)]
    for (idx in ord) {
      if (!is.finite(roll_v[idx])) next
      if (all(abs(idx - picked) >= (n_pre + n_crisis))) {
        picked <- c(picked, idx)
        if (length(picked) >= 4L) break
      }
    }
    picked <- sort(picked)
    if (!length(picked)) picked <- floor(nrow(usd_returns) / 2L)
    out <- data.frame(
      evento = paste0("Episodio_Auto_", seq_along(picked)),
      fecha = dates[picked],
      tipo_shock = "Endogeno_Detectado",
      mercado_origen = "Ambas",
      es_base_original = TRUE,
      stringsAsFactors = FALSE
    )
  }
  rownames(out) <- NULL
  out
}

MASS_ginv_fallback <- function(A, tol = 1e-10) {
  sv <- svd(A)
  pos <- sv$d > max(tol * sv$d[1L], 0)
  if (!any(pos)) return(matrix(0, nrow(A), ncol(A)))
  sv$v[, pos, drop = FALSE] %*% ((1 / sv$d[pos]) * t(sv$u[, pos, drop = FALSE]))
}

fit_factors <- function(design, x, rows) {
  sub_d <- design[rows, , drop = FALSE]
  sub_x <- x[rows, , drop = FALSE]
  fit <- stats::lm.fit(sub_d, sub_x)
  if (fit$rank < ncol(sub_d)) {
    co <- MASS_ginv_fallback(crossprod(sub_d)) %*% crossprod(sub_d, sub_x)
    return(co)
  }
  fit$coefficients
}

factor_paths <- function(x, f, window = 126L) {
  b <- array(NA_real_, c(nrow(x), ncol(x), ncol(f)))
  residuals <- x * NA_real_
  design <- cbind(1, f)
  for (i in seq.int(window + 1L, nrow(x))) {
    co <- fit_factors(design, x, seq.int(i - window, i - 1L))
    residuals[i, ] <- x[i, ] - drop(design[i, , drop = FALSE] %*% co)
    b[i, , ] <- t(co[-1L, , drop = FALSE])
  }
  list(residuals = residuals, betas = b)
}

coefficients_ab <- function(theta) {
  w <- exp(c(0, theta) - max(c(0, theta)))
  0.9995 * w[-1L] / sum(w)
}

garch_variance <- function(e, h0, ab) {
  omega <- (1 - sum(ab)) * h0
  step <- omega + ab[1L] * head(e, -1L)^2
  h <- c(h0, as.numeric(stats::filter(step, ab[2L], method = "recursive", init = h0)))
  pmax(h, 1e-10)
}

fit_garch <- function(y) {
  mu <- mean(y)
  h0 <- stats::var(y)
  e <- y - mu
  if (!is.finite(h0) || h0 <= 1e-10) stop("Varianza insuficiente para GARCH.")
  objective <- function(theta) {
    h <- garch_variance(e, h0, coefficients_ab(theta))
    mean(log(h) + e^2 / h)
  }
  starts <- list(log(c(0.06, 0.88) / 0.06), log(c(0.10, 0.80) / 0.10))
  opts <- lapply(starts, function(st) {
    tryCatch(stats::optim(st, objective, method = "L-BFGS-B",
                          lower = rep(-14, 2L), upper = rep(14, 2L)),
             error = function(err) list(convergence = 1L, value = Inf))
  })
  ok <- vapply(opts, function(z) z$convergence == 0L && is.finite(z$value), logical(1L))
  best <- if (any(ok)) {
    opts[ok][[which.min(vapply(opts[ok], function(z) z$value, numeric(1L)))]]
  } else {
    stats::optim(starts[[1L]], objective, method = "Nelder-Mead")
  }
  ab <- coefficients_ab(best$par)
  list(mu = mu, h0 = h0, ab = ab, gamma = 0, h = garch_variance(e, h0, ab), type = "GARCH")
}

filter_dcc <- function(z, target, ab, likelihood = FALSE) {
  n <- nrow(z)
  k <- ncol(z)
  q <- target
  c0 <- (1 - sum(ab)) * target
  if (!likelihood) path <- array(NA_real_, c(k, k, n))
  loss <- 0
  for (i in seq_len(n)) {
    d_inv <- 1 / sqrt(pmax(diag(q), 1e-12))
    r <- q * tcrossprod(d_inv)
    diag(r) <- 1
    if (likelihood) {
      u <- tryCatch(chol(r), error = function(e) NULL)
      if (is.null(u)) return(1e10)
      v <- backsolve(u, z[i, ], transpose = TRUE)
      loss <- loss + 2 * sum(log(diag(u))) + sum(v^2)
    } else {
      path[, , i] <- r
    }
    if (i < n) q <- c0 + ab[1L] * tcrossprod(z[i, ]) + ab[2L] * q
  }
  if (likelihood) loss / n else path
}

fit_dcc <- function(x) {
  fits <- setNames(lapply(seq_len(ncol(x)), function(j) fit_garch(x[, j])), colnames(x))
  mu <- vapply(fits, function(f) f$mu, numeric(1L))
  h <- vapply(fits, function(f) f$h, numeric(nrow(x)))
  z <- sweep(x, 2L, mu, "-") / sqrt(h)
  target <- crossprod(z) / nrow(z) + diag(1e-8, ncol(x))
  objective <- function(theta) filter_dcc(z, target, coefficients_ab(theta), TRUE)
  opts <- lapply(list(c(0.035, 0.94), c(0.12, 0.75)), function(a) {
    tryCatch(stats::optim(log(a / (1 - sum(a))), objective, method = "L-BFGS-B",
                          lower = rep(-14, 2L), upper = rep(14, 2L),
                          control = list(maxit = 180L)),
             error = function(err) list(convergence = 1L, value = Inf))
  })
  ok <- vapply(opts, function(z) z$convergence == 0L && is.finite(z$value), logical(1L))
  best <- if (any(ok)) {
    opts[ok][[which.min(vapply(opts[ok], function(z) z$value, numeric(1L)))]]
  } else {
    stats::optim(log(c(0.035, 0.94) / 0.025), objective, method = "Nelder-Mead")
  }
  list(fits = fits, target = target, ab = coefficients_ab(best$par), g_adcc = 0, type = "DCC")
}

dcc_path <- function(model, x) {
  e <- sweep(x, 2L, vapply(model$fits, function(z) z$mu, numeric(1L)), "-")
  h <- vapply(seq_len(ncol(x)), function(j) {
    f <- model$fits[[j]]
    garch_variance(e[, j], f$h0, f$ab)
  }, numeric(nrow(x)))
  z <- e / sqrt(h)
  corr <- filter_dcc(z, model$target, model$ab, FALSE)
  list(h = h, z = z, corr = corr)
}

pair_indexes <- function(x) utils::combn(ncol(x), 2L)

pair_values <- function(m, pairs) m[cbind(pairs[1L, ], pairs[2L, ])]

correlation_paths <- function(x, dates, model, window = 60L) {
  dcc <- dcc_path(model, x)
  pairs <- pair_indexes(x)
  labels <- apply(pairs, 2L, function(j) paste(colnames(x)[j], collapse = "__"))
  dynamic <- t(matrix(vapply(seq_len(nrow(x)), function(i) {
    pair_values(dcc$corr[, , i], pairs)
  }, numeric(length(labels))), nrow = length(labels)))
  mobile <- matrix(NA_real_, nrow(x), length(labels))
  if (nrow(x) >= window) {
    for (i in seq.int(window, nrow(x))) {
      mobile[i, ] <- pair_values(stats::cor(x[seq.int(i - window + 1L, i), , drop = FALSE]), pairs)
    }
  }
  colnames(dynamic) <- colnames(mobile) <- labels
  list(dates = dates, dcc = dynamic, mobile = mobile, z = dcc$z, h = dcc$h, corr_array = dcc$corr)
}

currency_equity_decomposition <- function(dates, usd, local, fx, events) {
  pairs <- pair_indexes(usd)
  compute_slice <- function(rows, label) {
    u <- usd[rows, , drop = FALSE]
    l <- local[rows, , drop = FALSE]
    s <- fx[rows, , drop = FALSE]
    sd_u <- apply(u, 2L, stats::sd)
    cov_u <- stats::cov(u)
    cov_l <- stats::cov(l)
    cov_s <- stats::cov(s)
    cov_ls <- stats::cov(l, s)

    do.call(rbind, lapply(seq_len(ncol(pairs)), function(idx) {
      i <- pairs[1L, idx]
      j <- pairs[2L, idx]
      denom <- max(sd_u[i] * sd_u[j], 1e-12)
      corr_usd <- cov_u[i, j] / denom
      comp_eq <- cov_l[i, j] / denom
      comp_fx <- cov_s[i, j] / denom
      comp_cross <- (cov_ls[i, j] + cov_ls[j, i]) / denom
      corr_loc_pure <- cov_l[i, j] / max(stats::sd(l[, i]) * stats::sd(l[, j]), 1e-12)
      corr_fx_pure <- cov_s[i, j] / max(stats::sd(s[, i]) * stats::sd(s[, j]), 1e-12)

      data.frame(
        regimen = label,
        par = paste0(colnames(usd)[i], "__", colnames(usd)[j]),
        mercado_a = colnames(usd)[i],
        mercado_b = colnames(usd)[j],
        sesiones = length(rows),
        corr_usd_total = corr_usd,
        aporte_bolsa_local = comp_eq,
        aporte_tipo_cambio = comp_fx,
        aporte_cruzado_bolsa_fx = comp_cross,
        proporcion_canal_cambiario_y_cruzado = if (abs(corr_usd) > 0.02) {
          (comp_fx + comp_cross) / corr_usd
        } else {
          NA_real_
        },
        corr_pura_bolsa_local = corr_loc_pure,
        corr_pura_fx = corr_fx_pure,
        stringsAsFactors = FALSE
      )
    }))
  }

  slices <- list(compute_slice(seq_len(nrow(usd)), "Muestra_Completa"))
  for (e_i in seq_len(nrow(events))) {
    anch <- events$fecha[e_i]
    pre <- tail(which(dates < anch), 120L)
    cri <- head(which(dates >= anch), 30L)
    if (length(pre) == 120L && length(cri) == 30L) {
      slices[[length(slices) + 1L]] <- compute_slice(pre, paste0(events$evento[e_i], "_Pre120"))
      slices[[length(slices) + 1L]] <- compute_slice(cri, paste0(events$evento[e_i], "_Crisis30"))
    }
  }

  # Ademas, varianza por pais: Var(r_usd) = Var(r_local) + Var(s_fx) + 2 Cov(r_local, s_fx)
  country_var <- do.call(rbind, lapply(seq_len(ncol(usd)), function(j) {
    v_u <- stats::var(usd[, j])
    v_l <- stats::var(local[, j])
    v_s <- stats::var(fx[, j])
    c_ls <- 2 * stats::cov(local[, j], fx[, j])
    corr_ls <- stats::cor(local[, j], fx[, j])
    data.frame(
      mercado = colnames(usd)[j],
      var_usd = v_u,
      var_bolsa_local = v_l,
      var_fx = v_s,
      dos_cov_bolsa_fx = c_ls,
      pct_var_bolsa_local = 100 * v_l / max(v_u, 1e-12),
      pct_var_fx = 100 * v_s / max(v_u, 1e-12),
      pct_var_cruzada = 100 * c_ls / max(v_u, 1e-12),
      corr_interna_bolsa_aprec_fx = corr_ls,
      stringsAsFactors = FALSE
    )
  }))

  list(pairs = do.call(rbind, slices), countries = country_var)
}

event_rows <- function(dates, anchor, n_pre, n_crisis) {
  pre <- tail(which(dates < anchor), n_pre)
  crisis <- head(which(dates >= anchor), n_crisis)
  if (length(pre) != n_pre || length(crisis) != n_crisis) {
    stop("Ventana incompleta alrededor de ", anchor)
  }
  list(pre = pre, crisis = crisis)
}

block_sample <- function(n, size) {
  starts <- sample.int(n, ceiling(n / size), replace = TRUE)
  head(as.vector(outer(seq_len(size) - 1L, starts - 1L, "+") %% n) + 1L, n)
}

fr_effect <- function(pre, crisis, pairs) {
  var0 <- diag(stats::var(pre))
  var1 <- diag(stats::var(crisis))
  if (any(var0 < 1e-12 | var1 < 1e-12)) return(NULL)
  rho0 <- pair_values(stats::cor(pre), pairs)
  rho1 <- pair_values(stats::cor(crisis), pairs)
  delta <- var1 / var0 - 1
  adjusted <- function(direction) {
    denom <- 1 + delta[pairs[direction, ]] * (1 - rho1^2)
    rho1 / sqrt(pmax(denom, 1e-8))
  }
  rbind(before = rho0, after = rho1, raw = rho1 - rho0,
        fr_a = adjusted(1L) - rho0, fr_b = adjusted(2L) - rho0,
        delta_a = delta[pairs[1L, ]], delta_b = delta[pairs[2L, ]])
}

contrast_event <- function(dates, x, f, event, anchor, origin_market, n_pre, n_crisis, block, B) {
  w <- event_rows(dates, anchor, n_pre, n_crisis)
  all_rows <- c(w$pre, w$crisis)
  values <- x[all_rows, , drop = FALSE]
  design <- if (!is.null(f)) cbind(1, f[all_rows, , drop = FALSE])
  p <- pair_indexes(x)
  base_rows <- seq_len(n_pre)
  crisis_rows <- n_pre + seq_len(n_crisis)
  compare <- function(idx_pre, idx_crisis) {
    ids <- c(idx_pre, n_pre + idx_crisis)
    z <- values[ids, , drop = FALSE]
    if (!is.null(design)) {
      f2 <- design[ids, , drop = FALSE]
      fit <- stats::lm.fit(f2[base_rows, , drop = FALSE], z[base_rows, , drop = FALSE])
      if (fit$rank < ncol(f2)) return(NULL)
      z <- z - f2 %*% fit$coefficients
    }
    fr_effect(z[base_rows, , drop = FALSE], z[crisis_rows, , drop = FALSE], p)
  }
  observed <- compare(base_rows, seq_len(n_crisis))
  if (is.null(observed)) stop("Varianza insuficiente en el episodio ", event)
  estimated <- observed[c("raw", "fr_a", "fr_b"), , drop = FALSE]
  exceed <- estimated * 0
  complete <- attempts <- 0L
  max_attempts <- B + max(250L, ceiling(B / 4))
  while (complete < B && attempts < max_attempts) {
    attempts <- attempts + 1L
    replicate <- compare(block_sample(n_pre, block), block_sample(n_crisis, block))
    if (is.null(replicate)) next
    draw <- replicate[rownames(estimated), , drop = FALSE]
    exceed <- exceed + (draw - estimated >= estimated)
    complete <- complete + 1L
  }
  if (complete < max(20L, floor(0.8 * B))) stop("Remuestreo insuficiente en ", event)
  probs <- (1 + exceed) / (complete + 1)
  a <- colnames(x)[p[1L, ]]
  b <- colnames(x)[p[2L, ]]
  orig_a <- origin_market != "Ambas" & a == origin_market
  orig_b <- origin_market != "Ambas" & b == origin_market
  official <- ifelse(orig_a, probs["fr_a", ],
                     ifelse(orig_b, probs["fr_b", ], pmax(probs["fr_a", ], probs["fr_b", ])))
  fuente_lbl <- ifelse(orig_a | orig_b, origin_market, "Ambas")

  data.frame(
    evento = event, mercado_a = a, mercado_b = b,
    antes_desde = min(dates[w$pre]), antes_hasta = max(dates[w$pre]),
    crisis_desde = min(dates[w$crisis]), crisis_hasta = max(dates[w$crisis]),
    n_antes = n_pre, n_crisis = n_crisis, r_antes = observed["before", ],
    r_crisis = observed["after", ], cambio_bruto = estimated["raw", ],
    r_FR_fuente_a = observed["before", ] + estimated["fr_a", ],
    r_FR_fuente_b = observed["before", ] + estimated["fr_b", ],
    cambio_FR_a = estimated["fr_a", ], cambio_FR_b = estimated["fr_b", ],
    cambio_var_a = observed["delta_a", ], cambio_var_b = observed["delta_b", ],
    p_bruto = probs["raw", ], p_FR_a = probs["fr_a", ], p_FR_b = probs["fr_b", ],
    p_FR = official, fuente = fuente_lbl,
    replicas_validas = complete, replicas_descartadas = attempts - complete,
    row.names = NULL, stringsAsFactors = FALSE
  )
}

weekly_panel <- function(dates, x, f) {
  monday <- dates - (as.POSIXlt(dates)$wday + 6L) %% 7L
  agg <- rowsum(cbind(x, f), as.character(monday), reorder = TRUE)[-1L, , drop = FALSE]
  k <- ncol(x)
  list(dates = as.Date(rownames(agg)), x = agg[, seq_len(k), drop = FALSE],
       f = agg[, k + seq_len(ncol(f)), drop = FALSE])
}

contrast_scenario <- function(name, dates, x, f, events, pre, crisis, block, B,
                              weekly = FALSE) {
  rows_list <- lapply(seq_len(nrow(events)), function(i) {
    anchor <- events$fecha[i]
    keep <- !weekly | dates >= anchor | dates + 4 < anchor
    if (sum(dates[keep] < anchor) < pre || sum(dates[keep] >= anchor) < crisis) return(NULL)
    controls <- if (!is.null(f)) f[keep, , drop = FALSE]
    res <- contrast_event(dates[keep], x[keep, , drop = FALSE], controls,
                          events$evento[i], anchor, events$mercado_origen[i],
                          pre, crisis, block, B)
    res$es_base_original <- events$es_base_original[i]
    res
  })
  rows_list <- Filter(Negate(is.null), rows_list)
  if (!length(rows_list)) return(NULL)
  all <- do.call(rbind, rows_list)
  all$escenario <- name
  all$p_bruto_Holm <- stats::p.adjust(all$p_bruto, "holm")
  all$p_FR_Holm <- stats::p.adjust(all$p_FR, "holm")
  # Ajuste Holm restringido a los 4 episodios base originales para comparabilidad directa
  all$p_bruto_Holm_4ep <- NA_real_
  all$p_FR_Holm_4ep <- NA_real_
  idx4 <- which(all$es_base_original)
  if (length(idx4)) {
    all$p_bruto_Holm_4ep[idx4] <- stats::p.adjust(all$p_bruto[idx4], "holm")
    all$p_FR_Holm_4ep[idx4] <- stats::p.adjust(all$p_FR[idx4], "holm")
  }
  all
}

describe_events <- function(paths, events, layer) {
  rows <- lapply(seq_len(nrow(events)), function(i) {
    anch <- events$fecha[i]
    if (sum(paths$dates < anch) < 120L || sum(paths$dates >= anch) < 30L) return(NULL)
    w <- event_rows(paths$dates, anch, 120L, 30L)
    before_dcc <- colMeans(paths$dcc[w$pre, , drop = FALSE], na.rm = TRUE)
    after_dcc <- colMeans(paths$dcc[w$crisis, , drop = FALSE], na.rm = TRUE)
    before_mobile <- colMeans(paths$mobile[w$pre, , drop = FALSE], na.rm = TRUE)
    after_mobile <- colMeans(paths$mobile[w$crisis, , drop = FALSE], na.rm = TRUE)
    data.frame(capa = layer, evento = events$evento[i], par = colnames(paths$dcc),
               dcc_antes = before_dcc, dcc_crisis = after_dcc,
               cambio_dcc = after_dcc - before_dcc, movil_antes = before_mobile,
               movil_crisis = after_mobile, cambio_movil = after_mobile - before_mobile,
               row.names = NULL, stringsAsFactors = FALSE)
  })
  do.call(rbind, Filter(Negate(is.null), rows))
}

min_variance <- function(sigma, supports = NULL, lower_bound = 0) {
  k <- nrow(sigma)
  sigma <- (sigma + t(sigma)) / 2 + diag(1e-8, k)
  if (lower_bound < 0 || lower_bound * k >= 1 - 1e-6) {
    stop("Cota inferior inviable en min_variance.")
  }
  rem_mass <- 1 - k * lower_bound

  # Transformacion exacta w = lower_bound * 1 + rem_mass * v, con v >= 0, sum(v) = 1:
  # Minimiza (1/2) v' A v + b' v, sujeto a v >= 0, 1'v = 1
  A <- (rem_mass^2) * sigma
  b <- rem_mass * lower_bound * as.double(sigma %*% rep(1, k))

  if (k <= 10L) {
    if (is.null(supports)) {
      supports <- do.call(c, lapply(seq_len(k), function(m) utils::combn(k, m, simplify = FALSE)))
    }
    best <- Inf
    answer <- NULL
    for (active in supports) {
      m <- length(active)
      A_sub <- A[active, active, drop = FALSE]
      b_sub <- b[active]
      # KKT sobre el soporte activo: A_sub v_sub + b_sub - lambda 1 = 0, 1' v_sub = 1
      invA_1 <- tryCatch(solve(A_sub, rep(1, m)), error = function(e) NULL)
      if (is.null(invA_1)) next
      invA_b <- tryCatch(solve(A_sub, b_sub), error = function(e) NULL)
      if (is.null(invA_b)) next
      denom <- sum(invA_1)
      if (!is.finite(denom) || denom <= 1e-12) next
      lam <- (1 + sum(invA_b)) / denom
      v_sub <- lam * invA_1 - invA_b
      if (any(!is.finite(v_sub)) || any(v_sub < -1e-9)) next
      v <- numeric(k)
      v[active] <- pmax(v_sub, 0)
      v <- v / sum(v)
      w <- lower_bound + rem_mass * v
      risk <- drop(crossprod(w, sigma %*% w))
      if (risk < best) {
        best <- risk
        answer <- w
      }
    }
    if (!is.null(answer)) return(answer)
  }

  # Respaldo escalable Frank-Wolfe en el simplejo para cualquier dimension K > 10
  v <- rep(1 / k, k)
  for (iter in seq_len(400L)) {
    grad <- as.double(A %*% v + b)
    j_min <- which.min(grad)
    s <- numeric(k)
    s[j_min] <- 1
    d <- s - v
    denom_q <- drop(crossprod(d, A %*% d))
    step <- if (denom_q > 1e-12) min(max(-sum(grad * d) / denom_q, 0), 1) else (2 / (iter + 2))
    if (step < 1e-9) break
    v <- v + step * d
  }
  w <- lower_bound + rem_mass * (v / sum(v))
  w / sum(w)
}

factor_covariance_bhz <- function(x_win, f_win) {
  # Bekaert, Hodrick & Zhang (2009): modelo factorial Global + Regional ortogonalizado
  reg <- rowMeans(x_win)
  reg_orth <- stats::lm.fit(cbind(1, f_win), reg)$residuals
  F_all <- cbind(f_win, Reg_Ort = reg_orth)
  fit <- stats::lm.fit(cbind(1, F_all), x_win)
  B <- t(fit$coefficients[-1L, , drop = FALSE])
  Sigma_F <- stats::cov(F_all)
  idio_var <- apply(fit$residuals, 2L, stats::var)
  B %*% Sigma_F %*% t(B) + diag(pmax(idio_var, 1e-6), ncol(x_win))
}

shrink_covariance <- function(sigma, shrink = 0.20) {
  k <- nrow(sigma)
  avg_var <- mean(diag(sigma))
  (1 - shrink) * sigma + shrink * diag(avg_var, k)
}

portfolio_backtest <- function(x, dates, local_x = NULL, factors = NULL,
                               train_n = 500L, bps = 10, refit_dcc = TRUE) {
  if (nrow(x) <= train_n + 30L) {
    train_n <- max(120L, floor(0.35 * nrow(x)))
  }
  training <- x[seq_len(train_n), , drop = FALSE]
  model <- fit_dcc(training)
  path_fixed <- dcc_path(model, x)
  observed <- expm1(x / 100)
  k <- ncol(x)
  supports <- if (k <= 10L) {
    do.call(c, lapply(seq_len(k), function(m) utils::combn(k, m, simplify = FALSE)))
  } else {
    NULL
  }

  static <- min_variance(stats::cov(training), supports)
  strategies <- c(
    "Estatica",
    "DCC",
    "DCC_Shrink_Reestimado",
    "Historica_movil",
    "MinVar_Restringida_1_2N",
    "Factor_Global_Regional",
    "MinVar_Sin_Ruido_FX",
    "Equiponderada"
  )
  if (!refit_dcc) strategies <- setdiff(strategies, "DCC_Shrink_Reestimado")
  oos <- seq.int(train_n + 1L, nrow(x))
  ym <- format(dates[oos], "%Y-%m")
  rebalance <- !duplicated(ym)
  yr <- format(dates[oos], "%Y")
  annual_refit <- !duplicated(yr)

  gross <- net <- turnover <- matrix(0, length(oos), length(strategies),
                                     dimnames = list(NULL, strategies))
  allocations <- vector("list", sum(rebalance))
  n_alloc <- 0L
  holdings <- NULL
  rolling_dcc_model <- model
  path_rolling <- path_fixed

  for (i in seq_along(oos)) {
    t <- oos[i]
    # Reestimar DCC una vez al ano con ventana movil/expansiva estrictamente previa a t
    if (refit_dcc && annual_refit[i] && i > 1L) {
      est_rows <- seq.int(max(1L, t - 1260L), t - 1L)
      rolling_dcc_model <- tryCatch(fit_dcc(x[est_rows, , drop = FALSE]),
                                    error = function(e) rolling_dcc_model)
      path_rolling <- dcc_path(rolling_dcc_model, x)
    }

    if (rebalance[i]) {
      sigma_dcc <- path_fixed$corr[, , t] * tcrossprod(sqrt(path_fixed$h[t, ]))
      sigma_dcc_shr <- shrink_covariance(
        path_rolling$corr[, , t] * tcrossprod(sqrt(path_rolling$h[t, ])),
        shrink = 0.20
      )
      win_len <- min(252L, t - 1L)
      window <- seq.int(t - win_len, t - 1L)
      cov_hist <- stats::cov(x[window, , drop = FALSE])

      w_demiguel <- min_variance(cov_hist, supports, lower_bound = 1 / (2 * k))

      w_factor <- if (!is.null(factors)) {
        f_win <- factors[window, , drop = FALSE]
        ok_f <- rowSums(!is.finite(f_win)) == 0L
        if (sum(ok_f) >= 60L) {
          min_variance(factor_covariance_bhz(x[window[ok_f], , drop = FALSE],
                                             f_win[ok_f, , drop = FALSE]), supports)
        } else {
          min_variance(cov_hist, supports)
        }
      } else {
        min_variance(cov_hist, supports)
      }

      w_local <- if (!is.null(local_x)) {
        min_variance(stats::cov(local_x[window, , drop = FALSE]), supports)
      } else {
        min_variance(cov_hist, supports)
      }

      weights <- cbind(
        static,
        min_variance(sigma_dcc, supports),
        min_variance(sigma_dcc_shr, supports),
        min_variance(cov_hist, supports),
        w_demiguel,
        w_factor,
        w_local,
        rep(1 / k, k)
      )
      if (!refit_dcc) weights <- weights[, -3L, drop = FALSE]
      colnames(weights) <- strategies
      stopifnot(all(weights >= -1e-10), all(abs(colSums(weights) - 1) < 1e-8))
      weights <- sweep(pmax(weights, 0), 2L, colSums(pmax(weights, 0)), "/")

      turnover[i, ] <- if (i == 1L) 1 else colSums(abs(weights - holdings)) / 2
      holdings <- weights
      n_alloc <- n_alloc + 1L
      allocations[[n_alloc]] <- data.frame(
        fecha = dates[t],
        estrategia = rep(strategies, each = k),
        mercado = rep(colnames(x), length(strategies)),
        peso = as.vector(weights),
        stringsAsFactors = FALSE
      )
    }
    realized <- observed[t, ]
    gross[i, ] <- drop(crossprod(realized, holdings))
    net[i, ] <- (1 - turnover[i, ] * bps / 10000) * (1 + gross[i, ]) - 1
    holdings <- sweep(holdings * (1 + realized), 2L, 1 + gross[i, ], "/")
  }

  # Evaluacion complementaria de cobertura cambiaria (Ang & Bekaert 2002):
  # compara cartera GMV en retornos locales cubiertos vs. USD sin cubrir
  fx_hedge_comp <- NULL
  if (!is.null(local_x)) {
    obs_loc <- expm1(local_x / 100)
    h_loc <- rep(1 / k, k)
    net_loc_gmv <- net_loc_ew <- numeric(length(oos))
    for (i in seq_along(oos)) {
      t <- oos[i]
      if (rebalance[i]) {
        win_len <- min(252L, t - 1L)
        w_l <- min_variance(stats::cov(local_x[seq.int(t - win_len, t - 1L), , drop = FALSE]), supports)
        turn_l <- if (i == 1L) 1 else sum(abs(w_l - h_loc)) / 2
        h_loc <- w_l
      } else {
        turn_l <- 0
      }
      r_l <- obs_loc[t, ]
      g_l <- sum(r_l * h_loc)
      net_loc_gmv[i] <- (1 - turn_l * bps / 10000) * (1 + g_l) - 1
      net_loc_ew[i] <- mean(r_l)
      h_loc <- h_loc * (1 + r_l) / (1 + g_l)
    }
    years_oos <- as.numeric(max(dates[oos]) - dates[train_n]) / 365.25
    per_yr <- length(oos) / years_oos
    summ_vec <- function(r_v, label) {
      w_c <- c(1, cumprod(1 + r_v))
      cagr <- 100 * (tail(w_c, 1L)^(1 / years_oos) - 1)
      vol <- 100 * stats::sd(r_v) * sqrt(per_yr)
      sh <- (mean(r_v) * per_yr) / max(stats::sd(r_v) * sqrt(per_yr), 1e-12)
      mdd <- 100 * min(w_c / cummax(w_c) - 1)
      data.frame(esquema = label, CAGR_neto_pct = cagr, vol_anual_pct = vol,
                 Sharpe_anual = sh, max_drawdown_pct = mdd, stringsAsFactors = FALSE)
    }
    fx_hedge_comp <- rbind(
      summ_vec(net[, "Historica_movil"], "GMV_Movil_USD_SinCubrir"),
      summ_vec(net[, "MinVar_Sin_Ruido_FX"], "GMV_PesosLocales_Evaluada_USD"),
      summ_vec(net_loc_gmv, "GMV_Movil_MonedaLocal_CubiertaTeorica"),
      summ_vec(net[, "Equiponderada"], "Equiponderada_USD_SinCubrir"),
      summ_vec(net_loc_ew, "Equiponderada_MonedaLocal_CubiertaTeorica")
    )
  }

  list(dates = dates[oos], start = dates[train_n], weights = do.call(rbind, allocations),
       gross = gross, net = net, turnover = turnover, model = model,
       fx_hedging = fx_hedge_comp)
}

jobson_korkie_memmel_p <- function(r_i, r_bench) {
  if (max(abs(r_i - r_bench)) < 1e-12) return(1)
  n <- length(r_i)
  mu1 <- mean(r_i)
  mu2 <- mean(r_bench)
  s1 <- stats::sd(r_i)
  s2 <- stats::sd(r_bench)
  s12 <- stats::cov(r_i, r_bench)
  rho <- s12 / max(s1 * s2, 1e-12)
  sr1 <- mu1 / max(s1, 1e-12)
  sr2 <- mu2 / max(s2, 1e-12)
  theta <- (1 / n) * (2 * (1 - rho) + 0.5 * (sr1^2 + sr2^2 - 2 * sr1 * sr2 * rho^2))
  z <- (sr1 - sr2) / sqrt(max(theta, 1e-16))
  2 * stats::pnorm(-abs(z))
}

portfolio_metrics <- function(p, events) {
  years <- as.numeric(max(p$dates) - p$start) / 365.25
  periods <- length(p$dates) / years
  labels <- colnames(p$net)
  bench <- p$net[, "Equiponderada"]

  stats_fn <- function(x) {
    wealth <- c(1, cumprod(1 + x))
    c(retorno_pct = 100 * (tail(wealth, 1L) - 1),
      vol_anual_pct = 100 * stats::sd(x) * sqrt(periods),
      max_drawdown_pct = 100 * min(wealth / cummax(wealth) - 1))
  }

  all <- do.call(rbind, lapply(labels, function(s) {
    r_net <- p$net[, s]
    summary <- stats_fn(r_net)
    mu_ann <- mean(r_net) * periods
    var_ann <- stats::var(r_net) * periods
    sharpe_ann <- mu_ann / max(sqrt(var_ann), 1e-12)
    ceq_1 <- 100 * (mu_ann - 0.5 * 1 * var_ann)
    ceq_5 <- 100 * (mu_ann - 0.5 * 5 * var_ann)
    p_jk <- jobson_korkie_memmel_p(r_net, bench)

    data.frame(
      estrategia = s,
      desde = min(p$dates),
      hasta = max(p$dates),
      sesiones = length(p$dates),
      sesiones_anuales = periods,
      retorno_bruto_pct = 100 * (prod(1 + p$gross[, s]) - 1),
      retorno_neto_pct = summary["retorno_pct"],
      CAGR_neto_pct = 100 * (prod(1 + r_net)^(1 / years) - 1),
      vol_anual_neta_pct = summary["vol_anual_pct"],
      Sharpe_anual_neto = sharpe_ann,
      p_JobsonKorkie_vs_1N = p_jk,
      CEQ_anual_gamma1_pct = ceq_1,
      CEQ_anual_gamma5_pct = ceq_5,
      max_drawdown_neto_pct = summary["max_drawdown_pct"],
      rotacion_anual_pct = 100 * sum(p$turnover[, s]) / years,
      row.names = NULL,
      stringsAsFactors = FALSE
    )
  }))

  by_event_list <- lapply(seq_len(nrow(events)), function(i) {
    j <- head(which(p$dates >= events$fecha[i]), 30L)
    if (length(j) < 10L) return(NULL)
    z <- t(vapply(labels, function(s) stats_fn(p$net[j, s]), numeric(3L)))
    colnames(z) <- names(stats_fn(p$net[j, 1L]))
    data.frame(estrategia = labels, evento = events$evento[i],
               desde = min(p$dates[j]), hasta = max(p$dates[j]), sesiones = length(j),
               z, row.names = NULL, stringsAsFactors = FALSE)
  })
  by_event <- do.call(rbind, Filter(Negate(is.null), by_event_list))
  list(total = all, by_event = by_event)
}

model_diagnostics <- function(model, layer, z = NULL) {
  do.call(rbind, lapply(seq_along(model$fits), function(j) {
    fit <- model$fits[[j]]
    p <- c(NA_real_, NA_real_)
    if (!is.null(z)) {
      zj <- z[is.finite(z[, j]), j]
      p <- c(stats::Box.test(zj, 10L, type = "Ljung-Box")$p.value,
             stats::Box.test(zj^2, 10L, type = "Ljung-Box")$p.value)
    }
    gamma_val <- if (!is.null(fit$gamma)) fit$gamma else 0
    g_adcc_val <- if (!is.null(model$g_adcc)) model$g_adcc else 0
    k_val <- if (!is.null(fit$kappa)) fit$kappa else 0.5
    omega_val <- fit$h0 * max(0, 1 - sum(fit$ab) - k_val * gamma_val)

    data.frame(
      capa = layer,
      especificacion = model$type,
      mercado = names(model$fits)[j],
      media = fit$mu,
      omega = omega_val,
      alpha = fit$ab[1L],
      beta = fit$ab[2L],
      gamma_asimetria_vol = gamma_val,
      a_DCC = model$ab[1L],
      b_DCC = model$ab[2L],
      g_ADCC_asimetria_corr = g_adcc_val,
      persistencia_DCC = sum(model$ab) + 0.5 * g_adcc_val,
      p_LjungBox_z = p[1L],
      p_LjungBox_z2 = p[2L],
      stringsAsFactors = FALSE
    )
  }))
}

write_figures <- function(raw, adjusted, p, events, out) {
  # Figura 1: Correlacion regional en USD, residuos globales, VARX(1) y tipos de cambio FX
  plot_average <- function(z, title, extra_line = NULL, extra_lbl = NULL) {
    dcc <- rowMeans(z$dcc, na.rm = TRUE)
    mobile <- rowMeans(z$mobile, na.rm = TRUE)
    ylim_v <- range(c(dcc, mobile, extra_line), na.rm = TRUE)
    plot(z$dates, dcc, type = "l", col = "#1D4C77", lwd = 1.7,
         ylim = ylim_v, xlab = "", ylab = "Correlacion media", main = title)
    graphics::grid(col = "gray88", lty = 1)
    graphics::lines(z$dates, dcc, col = "#1D4C77", lwd = 1.7)
    graphics::lines(z$dates, mobile, col = "#A66324", lwd = 1.2)
    if (!is.null(extra_line)) {
      graphics::lines(z$dates, extra_line, col = "#2B7A4B", lwd = 1.4, lty = 2)
    }
    graphics::abline(v = as.numeric(events$fecha), lty = 3, col = "gray40")
    leg_txt <- c("DCC-GARCH", "Movil 60 sesiones")
    leg_col <- c("#1D4C77", "#A66324")
    leg_lty <- c(1, 1)
    if (!is.null(extra_line) && !is.null(extra_lbl)) {
      leg_txt <- c(leg_txt, extra_lbl)
      leg_col <- c(leg_col, "#2B7A4B")
      leg_lty <- c(leg_lty, 2)
    }
    graphics::legend("topleft", leg_txt, col = leg_col, lty = leg_lty, lwd = 1.6, bty = "n", cex = 0.88)
  }

  grDevices::png(file.path(out, "correlacion_regional.png"), width = 1550, height = 900, res = 140)
  tryCatch({
    graphics::par(mfrow = c(2, 1), mar = c(2.8, 4.6, 2.5, 1.2))
    plot_average(raw, "A. Retornos accionarios en USD (comovimiento total)")
    plot_average(adjusted, "B. Retornos en USD ajustados por factores globales")
  }, finally = grDevices::dev.off())

  # Figura 2: Carteras fuera de muestra (curvas de riqueza neta)
  keep_strat <- c("Estatica", "DCC", "DCC_Shrink_Reestimado", "Historica_movil",
                  "MinVar_Restringida_1_2N", "Factor_Global_Regional", "Equiponderada")
  keep_strat <- intersect(keep_strat, colnames(p$net))
  colors <- c("#4A5565", "#9B2C2C", "#1D4C77", "#A66324", "#2B7A4B", "#6B46C1", "#2C7A7B")
  wealth <- apply(p$net[, keep_strat, drop = FALSE], 2L, function(y) cumprod(1 + y))

  grDevices::png(file.path(out, "carteras_fuera_de_muestra.png"), width = 1550, height = 820, res = 140)
  tryCatch({
    graphics::par(mar = c(4.0, 4.8, 2.8, 1.2))
    plot(p$dates, wealth[, 1L], type = "n", ylim = range(wealth, na.rm = TRUE),
         xlab = "Fecha", ylab = "Valor neto por 1 USD inicial (escala log)", log = "y",
         main = "Desempeno fuera de muestra de carteras regionales (neto de 10 bps)")
    graphics::grid(col = "gray88", lty = 1)
    for (j in seq_len(ncol(wealth))) {
      graphics::lines(p$dates, wealth[, j], col = colors[j], lwd = 1.7)
    }
    graphics::abline(v = as.numeric(events$fecha), lty = 3, col = "gray45")
    graphics::legend("topleft", colnames(wealth), col = colors[seq_len(ncol(wealth))],
                     lty = 1, lwd = 1.8, bty = "n", cex = 0.85, ncol = 2)
  }, finally = grDevices::dev.off())

}

run_fin443 <- function(input = find_fin443_input(), out = "resultados", B = 499L,
                       seed = 443L) {
  set.seed(seed)
  message("1/5 Leyendo y auditando la base...")
  panel <- read_fin443(input)
  audit <- audit_fin443(panel)
  valid <- complete.cases(panel$factors)
  dates <- panel$dates[valid]
  x <- panel$usd[valid, , drop = FALSE]
  f <- panel$factors[valid, , drop = FALSE]
  local <- panel$local[valid, , drop = FALSE]
  fx <- panel$fx[valid, , drop = FALSE]
  if (nrow(x) < 300L) stop("Muestra insuficiente tras alinear los factores.")
  events <- resolve_events(dates, panel$markets, x)

  message("2/5 Estimando correlaciones moviles y DCC-GARCH en USD...")
  controls <- factor_paths(x, f)
  ok <- complete.cases(controls$residuals)
  residuals <- controls$residuals[ok, , drop = FALSE]
  raw_model <- fit_dcc(x)
  adjusted_model <- fit_dcc(residuals)
  raw <- correlation_paths(x, dates, raw_model)
  adjusted <- correlation_paths(residuals, dates[ok], adjusted_model)
  fx_decomp <- currency_equity_decomposition(dates, x, local, fx, events)

  message("3/5 Ejecutando Forbes-Rigobon (B = ", B, ")...")
  weekly <- weekly_panel(dates, x, f)
  scenarios <- Filter(Negate(is.null), list(
    contrast_scenario("USD_bruto_30", dates, x, NULL, events, 120L, 30L, 5L, B),
    contrast_scenario("USD_ajustado_30", dates, x, f, events, 120L, 30L, 5L, B),
    contrast_scenario("USD_ajustado_60", dates, x, f, events, 120L, 60L, 5L, B),
    contrast_scenario("USD_ajustado_semanal", weekly$dates, weekly$x, weekly$f,
                      events, 52L, 8L, 2L, B, weekly = TRUE)
  ))
  fr <- do.call(rbind, scenarios)
  summary_fr <- do.call(rbind, lapply(split(fr, list(fr$escenario, fr$evento), drop = TRUE), function(z) {
    data.frame(escenario = z$escenario[1L], evento = z$evento[1L], pares = nrow(z),
               cambio_bruto_promedio = mean(z$cambio_bruto),
               aumentos_brutos_Holm_5pct = sum(z$p_bruto_Holm < 0.05),
               aumentos_FR_Holm_5pct = sum(z$p_FR_Holm < 0.05),
               minimo_p_FR = min(z$p_FR), minimo_p_FR_Holm = min(z$p_FR_Holm))
  }))

  message("4/5 Evaluando carteras fuera de muestra...")
  p <- portfolio_backtest(panel$usd, panel$dates, local_x = panel$local,
                          factors = panel$factors, refit_dcc = FALSE)
  metrics <- portfolio_metrics(p, events)
  weights <- aggregate(peso ~ fecha + estrategia, p$weights, sum)
  stopifnot(all(is.finite(p$net)), all(abs(weights$peso - 1) < 1e-8),
            all(fr$replicas_validas == B), all(fr$p_FR_Holm >= 0 & fr$p_FR_Holm <= 1))

  message("5/5 Escribiendo tablas y figuras...")
  dir.create(out, recursive = TRUE, showWarnings = FALSE)
  save <- function(x, name) write.csv(x, file.path(out, paste0(name, ".csv")), row.names = FALSE, na = "")
  save_paths <- function(z, name) {
    dynamic <- setNames(as.data.frame(z$dcc), paste0("DCC_", colnames(z$dcc)))
    mobile <- setNames(as.data.frame(z$mobile), paste0("Movil_", colnames(z$mobile)))
    save(data.frame(fecha = z$dates, mobile, dynamic), name)
  }
  save(data.frame(desde = min(panel$dates), hasta = max(panel$dates), filas = length(panel$dates),
                  mercados = paste(panel$markets, collapse = ", "), filas_con_factores = length(dates),
                  n_mercados = ncol(x), n_pares = choose(ncol(x), 2L),
                  primera_sesion_fuera_muestra = min(p$dates),
                  na_imputados_totales = panel$cleaning$total_na_imputados,
                  fechas_duplicadas_colapsadas = panel$cleaning$fechas_duplicadas_colapsadas,
                  B = B, semilla = seed, md5_base = panel$cleaning$md5_base), "muestra")
  save(audit$cleaning, "auditoria_limpieza")
  save(audit$imputation, "auditoria_locf")
  save(audit$series, "auditoria_series")
  save(audit$prices, "auditoria_precios")
  save(events, "episodios_analizados")
  save(rbind(model_diagnostics(raw_model, "USD_bruto", raw$z),
             model_diagnostics(adjusted_model, "USD_ajustado", adjusted$z),
             model_diagnostics(p$model, "Cartera_entrenamiento_500")), "parametros_y_diagnosticos")
  save_paths(raw, "correlaciones_USD_bruto")
  save_paths(adjusted, "correlaciones_USD_ajustado")
  save(rbind(describe_events(raw, events, "USD_bruto"),
             describe_events(adjusted, events, "USD_ajustado")), "correlaciones_por_crisis")
  save(fx_decomp$countries, "descomposicion_varianza_moneda_pais")
  save(fx_decomp$pairs, "descomposicion_correlacion_moneda_pares")
  save(fr, "forbes_rigobon")
  save(summary_fr, "resumen_forbes_rigobon")
  save(metrics$total, "carteras_metricas")
  save(metrics$by_event, "carteras_por_crisis")
  save(p$weights, "carteras_pesos")
  save(p$fx_hedging, "carteras_cobertura_cambiaria")
  gross <- setNames(as.data.frame(p$gross), paste0("Bruto_", colnames(p$gross)))
  turnover <- setNames(as.data.frame(p$turnover), paste0("Rotacion_", colnames(p$turnover)))
  save(data.frame(fecha = p$dates, p$net, gross, turnover), "carteras_retornos")
  write_figures(raw, adjusted, p, events, out)
  writeLines(capture.output(sessionInfo()), file.path(out, "sesion_R.txt"))
  invisible(summary_fr)
}

