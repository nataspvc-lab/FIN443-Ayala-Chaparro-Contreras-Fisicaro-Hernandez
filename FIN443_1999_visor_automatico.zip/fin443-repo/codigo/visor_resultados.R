json_text <- function(x) {
  out <- encodeString(enc2utf8(as.character(x)), quote = '"', na.encode = FALSE)
  out[is.na(out)] <- '""'
  gsub("<", "\\u003c", out, fixed = TRUE)
}

json_list <- function(encoded) {
  paste0("[", paste(encoded, collapse = ","), "]")
}

encode_png <- function(path) {
  bytes <- as.integer(readBin(path, "raw", n = file.info(path)$size))
  padding <- (3L - length(bytes) %% 3L) %% 3L
  blocks <- matrix(c(bytes, rep.int(0L, padding)), nrow = 3L)
  codes <- rbind(
    blocks[1L, ] %/% 4L,
    (blocks[1L, ] %% 4L) * 16L + blocks[2L, ] %/% 16L,
    (blocks[2L, ] %% 16L) * 4L + blocks[3L, ] %/% 64L,
    blocks[3L, ] %% 64L
  )
  alphabet <- c(LETTERS, letters, as.character(0:9), "+", "/")
  encoded <- alphabet[as.vector(codes) + 1L]
  if (padding) encoded[seq.int(length(encoded) - padding + 1L, length(encoded))] <- "="
  paste0("data:image/png;base64,", paste(encoded, collapse = ""))
}

write_results_viewer <- function(out, code_dir) {
  index <- read.delim(file.path(code_dir, "salidas_visor.tsv"), encoding = "UTF-8")
  available <- file.exists(file.path(out, index$archivo))
  index <- index[available, , drop = FALSE]
  items <- vapply(seq_len(nrow(index)), function(i) {
    filename <- index$archivo[i]
    path <- file.path(out, filename)
    kind <- tools::file_ext(path)
    fields <- switch(kind,
      csv = {
        table <- read.csv(path, colClasses = "character", check.names = FALSE,
                          na.strings = NULL, encoding = "UTF-8")
        columns <- json_list(json_text(names(table)))
        values <- matrix(json_text(as.matrix(table)), nrow = nrow(table),
                         ncol = ncol(table))
        rows <- apply(values, 1L, json_list)
        paste0('"columns":', columns, ',"rows":', json_list(rows))
      },
      png = paste0('"content":', json_text(encode_png(path))),
      txt = paste0('"content":', json_text(paste(readLines(path, warn = FALSE,
                                                        encoding = "UTF-8"), collapse = "\n"))),
      stop("Formato de salida desconocido: ", kind)
    )
    paste0(json_text(filename), ':{ "label":', json_text(index$etiqueta[i]),
           ',"kind":', json_text(kind), ",", fields, "}")
  }, character(1))

  groups <- vapply(unique(index$grupo), function(group) {
    entries <- index[index$grupo == group, , drop = FALSE]
    pairs <- paste0("[", json_text(entries$archivo), ",", json_text(entries$etiqueta), "]")
    paste0(json_text(group), ":", json_list(pairs))
  }, character(1))
  payload <- paste0('{"groups":{', paste(groups, collapse = ","), '},"items":{',
                    paste(items, collapse = ","), "}}")

  template <- readLines(file.path(code_dir, "visor.html"), encoding = "UTF-8",
                        warn = FALSE)
  marker <- "__RESULTADOS_FIN443__"
  line <- which(grepl(marker, template, fixed = TRUE))
  stopifnot(length(line) == 1L)
  parts <- strsplit(template[line], marker, fixed = TRUE)[[1L]]
  template[line] <- paste0(parts[1L], payload, parts[2L])
  report <- file.path(out, "visor_resultados.html")
  writeLines(enc2utf8(template), report, useBytes = TRUE)
  normalizePath(report, winslash = "/")
}

open_results_viewer <- function(report) {
  if (!interactive()) return(invisible(NULL))
  viewer <- getOption("viewer")
  if (is.function(viewer)) {
    preview <- tempfile("fin443-", fileext = ".html")
    if (!file.copy(report, preview)) stop("No se pudo abrir el visor de resultados.")
    viewer(preview)
  } else {
    utils::browseURL(report)
  }
  invisible(NULL)
}
