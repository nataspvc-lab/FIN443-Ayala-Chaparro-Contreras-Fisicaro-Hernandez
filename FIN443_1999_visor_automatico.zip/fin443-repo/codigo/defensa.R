# Ejemplo: Rscript codigo/defensa.R Lehman 60 datos/base_unidas.csv
args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 2L || length(args) > 3L || !args[[2L]] %in% c("30", "60")) {
  stop("Uso: Rscript codigo/defensa.R EVENTO 30|60 [ruta_a_base]")
}
source(file.path("codigo", "analisis_fin443.R"))

event <- subset(default_crisis_catalog(), evento == args[[1L]])
if (nrow(event) != 1L) stop("Evento desconocido: ", args[[1L]])
input <- if (length(args) == 3L) args[[3L]] else file.path("datos", "base_unidas.csv")
n_crisis <- as.integer(args[[2L]])
panel <- read_fin443(input)
valid <- complete.cases(panel$factors)
dates <- panel$dates[valid]
returns <- panel$usd[valid, , drop = FALSE]
factors <- panel$factors[valid, , drop = FALSE]

set.seed(443L)
result <- contrast_scenario("USD_ajustado_defensa", dates, returns, factors, event,
                            pre = 120L, crisis = n_crisis, block = 5L, B = 499L)
if (is.null(result)) stop("La base no cubre las ventanas para el episodio solicitado.")
dir.create("resultados_defensa", showWarnings = FALSE)
path <- file.path("resultados_defensa", sprintf("FR_%s_%d.csv", args[[1L]], n_crisis))
write.csv(result, path, row.names = FALSE)
cat(args[[1L]], "| sesiones de crisis:", n_crisis,
    "| cambio medio de correlacion:", round(mean(result$cambio_bruto), 3),
    "| pares significativos FR (Holm dentro del episodio):",
    sum(result$p_FR_Holm < 0.05), "de", nrow(result), "\n")
message("Tabla: ", path)
