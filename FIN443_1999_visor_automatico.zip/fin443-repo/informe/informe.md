---
title: Contagio financiero multi-activo en América Latina, 2005–2025
lang: es
---

# 1. Pregunta y datos

¿Aumentó el comovimiento entre las bolsas de Argentina, Brasil, Chile, México y Perú en los episodios de crisis de 2005–2025, y cuánto de su correlación en dólares se asocia al canal cambiario?

La hoja `base` de `datos/base_unidas.xlsx` contiene 4.565 sesiones entre 2005-01-04 y 2025-12-30. Cada mercado tiene precios y retornos logarítmicos en moneda local y USD, y tipo de cambio en moneda local por dólar. S&P 500 y VIX aproximan las condiciones globales. La corrida utiliza el CSV equivalente. La base carece de una serie COLCAP y de metadatos sobre el proveedor original de cada índice. El universo observado comprende cinco mercados y diez pares.

# 2. Método

1. **Comovimiento.** Calculamos correlaciones móviles de 60 sesiones y DCC-GARCH (Engle, 2002) sobre retornos en USD y sobre residuos de regresiones móviles de 126 sesiones frente a S&P 500 y la variación logarítmica del VIX. Comparamos niveles antes y durante las crisis. DCC describe dependencia condicional.
2. **Contagio.** Forbes y Rigobon (2002) corrigen la correlación de crisis por el salto de varianza del mercado fuente. Comparamos 120 sesiones previas con 30 de crisis. En la especificación ajustada, estimamos las exposiciones con la ventana previa de cada episodio. Hacemos 1.999 réplicas bootstrap en bloques de 5 sesiones, con semilla 443 y Holm por escenario. Como robustez, extendemos la crisis a 60 sesiones y repetimos semanalmente con ventanas de 52 y 8 semanas y bloques de 2.
3. **Canal cambiario.** Usamos la identidad entre el retorno logarítmico en USD, el retorno local y la apreciación de la moneda. La covarianza entre dos bolsas en USD se descompone en covarianza bursátil local, covarianza cambiaria y dos términos cruzados. Los tres aportes suman la correlación en USD al dividir por las volatilidades de los dos retornos en USD.
4. **Carteras.** Después de una ventana inicial de 500 sesiones comparamos carteras regionales sin ventas cortas, con rebalanceo mensual y costo de 10 puntos base sobre la rotación. Los pesos de cada mes se calculan con información previa. DCC para cartera se ajusta en la muestra inicial. La equiponderada (1/N) es el contraste de referencia (DeMiguel et al., 2009).

# 3. Resultados

## 3.1 Comovimiento y Forbes–Rigobon

| Episodio | Δ DCC USD bruto | Δ correlación previa a FR | p FR mínimo | p Holm mínimo | Pares FR al 5 % |
|---|---:|---:|---:|---:|---:|
| Lehman | 0,211 | 0,392 | 0,3995 | 1,000 | 0/10 |
| Eurozona | 0,183 | 0,338 | 0,0010 | 0,089 | 0/10 |
| Taper Tantrum | -0,046 | -0,051 | 0,2145 | 1,000 | 0/10 |
| China / commodities | 0,067 | -0,064 | 0,3935 | 1,000 | 0/10 |
| PASO Argentina | 0,007 | 0,116 | 0,0005 | 0,045 | 1/10 |
| Estallido social Chile | -0,066 | 0,071 | 0,0335 | 1,000 | 0/10 |
| COVID-19 | 0,264 | 0,130 | 0,2525 | 1,000 | 0/10 |
| Alza de tasas Fed | 0,133 | 0,049 | 0,3240 | 1,000 | 0/10 |
| Devaluación argentina | -0,150 | -0,225 | 0,0300 | 1,000 | 0/10 |

: Cambio DCC en USD bruto de `correlaciones_por_crisis.csv`. Las otras columnas corresponden a Forbes–Rigobon con factores y ventana de 30 sesiones de `resumen_forbes_rigobon.csv`.

En Lehman, el aumento promedio de correlación antes de corregir por volatilidad fue 0,392 en la especificación con factores y 0,391 en USD bruto. Para Lehman, Forbes–Rigobon no detecta aumentos significativos después de Holm. Para las PASO de Argentina, el par Brasil–México registra p = 0,0005 y p ajustado de 0,045 en la ventana de 30 sesiones con factores. El mismo par es significativo en el contraste ajustado semanal, mientras que para las PASO no hay rechazos en la ventana ajustada de 60 sesiones. Con 1.999 réplicas, el p mínimo posible es 0,0005 y un Holm de 90 contrastes puede alcanzar 0,045 en el extremo de la distribución.

| Escenario | Contrastes | p FR mínimo | p Holm mínimo | Rechazos FR al 5 % |
|---|---:|---:|---:|---:|
| USD bruto · 30 sesiones | 90 | 0,0005 | 0,045 | 2 |
| USD ajustado · 30 sesiones | 90 | 0,0005 | 0,045 | 1 |
| USD ajustado · 60 sesiones | 90 | 0,0005 | 0,045 | 1 |
| USD ajustado · 8 semanas | 90 | 0,0005 | 0,045 | 2 |

![Correlación regional media DCC y móvil de 60 sesiones. Las líneas verticales indican episodios de la muestra.](../resultados/correlacion_regional.png)

## 3.2 Canal cambiario

En la muestra completa, el componente cambiario más el cruzado representa 56,0 % de la correlación Brasil–México y 55,3 % de Chile–México en USD. En Lehman representa 54,7 % de la correlación Brasil–México, de 0,935. Estas proporciones son contables y no identifican un efecto causal (`descomposicion_correlacion_moneda_pares.csv`).

## 3.3 Carteras fuera de muestra

| Estrategia | CAGR neto (%) | Vol. anual (%) | Sharpe | p vs. 1/N | Caída máx. (%) |
|---|---:|---:|---:|---:|---:|
| Mín. var. estática | 5,56 | 21,25 | 0,361 | 0,969 | -60,64 |
| Mín. var. DCC | 4,91 | 20,52 | 0,337 | 0,864 | -71,38 |
| Mín. var. móvil | 5,70 | 20,17 | 0,376 | 0,878 | -63,14 |
| Mín. var. restringida | 5,44 | 21,16 | 0,356 | 0,994 | -62,24 |
| Covarianza factorial | 4,38 | 20,21 | 0,313 | 0,736 | -66,62 |
| Pesos en moneda local | 3,90 | 20,44 | 0,289 | 0,553 | -56,95 |
| Equiponderada 1/N | 5,84 | 24,04 | 0,357 | — | -62,66 |

: `carteras_metricas.csv`. p corresponde al contraste Jobson–Korkie de igualdad de Sharpe.

La cartera de mínima varianza móvil tiene 20,17 % de volatilidad versus 24,04 % de 1/N. Su diferencia de Sharpe no resulta significativa al 5 % (p = 0,878). En el ejercicio de cobertura teórica la volatilidad baja a 14,81 %, antes de incorporar el costo de forwards (`carteras_cobertura_cambiaria.csv`).

# 4. Aporte propio

Descomponemos el comovimiento en USD en aportes bursátiles locales, cambiarios y cruzados. Esto permite discutir la diversificación de un inversionista en dólares y complementarla con una cobertura teórica fuera de muestra. Como contraste de robustez, usamos ventanas de crisis alternativas y frecuencia semanal.

# 5. Validación y replicabilidad

- El CSV reproduce la hoja Excel celda a celda. La fecha se estandarizó a AAAA-MM-DD. La auditoría de la corrida registra 0 imputaciones y 0 fechas duplicadas colapsadas.
- Las identidades de retornos y precios se auditan en `auditoria_precios.csv`. El máximo error absoluto registrado es 3.22e-13. Recalculamos la correlación Brasil–México de Lehman directamente con los retornos del CSV y verificamos que los pesos suman uno.
- `Rscript codigo/main.R` regeneró las tablas y figuras desde una carpeta de resultados vacía en R 4.3.3 para Windows en 2,76 minutos. `muestra.csv` registra el MD5 de la base, la semilla y las 1.999 réplicas.
- Al ejecutar `main.R` con Source en RStudio, el visor se abre con los resultados de esa corrida.
- El modo de defensa usa 499 réplicas y permite modificar en vivo la ventana de un episodio. Aplica Holm a los pares de ese episodio. Sus valores p ajustados corresponden a esa familia de pruebas más acotada.

# 6. Conclusiones

Las correlaciones subieron en episodios como Lehman. El contraste Forbes–Rigobon identifica un aumento en el par Brasil–México alrededor de las PASO de 2019 en la ventana de 30 sesiones con ajuste por factores. La evidencia es sensible a la ventana y se refiere a un cambio de correlación durante el episodio. La descomposición cambiaria muestra que cerca del 55 % de la correlación en USD de Brasil–México y Chile–México corresponde a moneda y términos cruzados. La mínima varianza reduce volatilidad frente a 1/N en la muestra, con diferencias de Sharpe no significativas para la comparación principal.

# Referencias citadas

Forbes, K. J., & Rigobon, R. (2002). No contagion, only interdependence: Measuring stock market comovements. The Journal of Finance, 57(5), 2223–2261. <https://doi.org/10.1111/0022-1082.00494>

Engle, R. (2002). Dynamic conditional correlation: A simple class of multivariate generalized autoregressive conditional heteroskedasticity models. Journal of Business & Economic Statistics, 20(3), 339–350. <https://doi.org/10.1198/073500102288618487>

DeMiguel, V., Garlappi, L., & Uppal, R. (2009). Optimal versus naive diversification: How inefficient is the 1/N portfolio strategy? The Review of Financial Studies, 22(5), 1915–1953. <https://doi.org/10.1093/rfs/hhm075>
