# Contribuciones (acordado por todo el grupo)

| Integrante | RUT | Usuario GitHub | Secciones del informe | Código | Datos | Referencias (n° en referencias_E2.csv) |
|---|---|---|---|---|---|---|
| Manuel Ayala | | | | | | |
| Natasha Chaparro | | | | | | |
| Isidora Contreras | | | | | | |
| Lucía Fisicaro | | | | | | |
| Martina Hernández | | | | | | |

Cada integrante es responsable de al menos 3 referencias. Los commits de cada uno en GitHub, hechos con su propia cuenta, respaldan esta tabla.
