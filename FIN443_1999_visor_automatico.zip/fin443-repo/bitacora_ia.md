# Bitácora de uso de IA

## 27 de noviembre de 2026 · ChatGPT/Codex

- **Solicitud de Natasha Chaparro.** Leer el enunciado de la Evaluación 2 y ejecutar y corregir la carpeta fin443-repo.
- **Trabajo de la IA.** Diagnosticó el fallo al instalar readxl, preparó el CSV a partir de la hoja original y dejó una entrada de ejecución con R base. Revisó el informe contra las tablas de resultados y distinguió la significancia de Fisher y la del bootstrap CPS.
- **Evidencia técnica.** El comando registra la sesión de R, el hash de la base utilizada, los controles de limpieza y los resultados de los contrastes. La bitácora recoge la revisión de esta sesión. Cada integrante debe agregar sus verificaciones personales y los demás usos de IA del grupo.
- **Referencias.** Los cuartiles JCR, las páginas de los artículos, el registro en el foro y los RUT de los responsables quedan a cargo del grupo.

## Ajuste de alcance y verificación

- La usuaria pidió reducir el bootstrap a 499 y concentrar la corrida en correlaciones móviles, DCC, Forbes–Rigobon y carteras. El código conserva la descomposición cambiaria del aporte propio y añade un modo de defensa por episodio.
- La corrida completa regeneró los resultados desde una carpeta vacía en Windows con R 4.3.3. Se cotejaron las 4.565 filas y 29 columnas con el Excel original. También se recalcularon la identidad de retornos en USD, la correlación Brasil–México en Lehman y las sumas de pesos.
- La tabla de referencias reúne candidatas del grupo. Las entradas con uso eliminado por el cambio de alcance requieren actualizarse antes de contar como referencias aplicadas.

## Corrida de 1.999 réplicas y visor

- La usuaria pidió que, al correr el script en clases, la hoja de resultados se abriera automáticamente en RStudio. Se integró el visor al punto de entrada y se configuró la corrida principal con 1.999 réplicas. El modo rápido para la defensa usa 499.
