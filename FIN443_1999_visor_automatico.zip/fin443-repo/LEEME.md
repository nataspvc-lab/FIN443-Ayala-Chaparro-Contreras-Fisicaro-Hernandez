# FIN443 · E2 · Contagio y comovimiento bursátil en América Latina

**Grupo** Ayala, Chaparro, Contreras, Fisicaro y Hernández.

## Pregunta

¿Aumentó el comovimiento entre las bolsas de Argentina, Brasil, Chile, México y Perú durante las crisis de 2005–2025, y cuánto de la correlación en dólares se asocia al canal cambiario?

## Datos

`datos/base_unidas.csv` reproduce las 4.565 sesiones y 29 columnas de la hoja `base` en `datos/base_unidas.xlsx`, con fechas ISO. La muestra diaria va del 4 de enero de 2005 al 30 de diciembre de 2025. Incluye precios y retornos logarítmicos en moneda local y USD, tipos de cambio por USD, S&P 500 y VIX. El Excel original no documenta el proveedor de cada serie.

## Ejecución completa

En RStudio, abre `codigo/main.R` y pulsa **Source**. Al terminar, la pestaña **Viewer** muestra las tablas y gráficos recién generados. El menú **Salida** permite cambiar de resultado. El HTML también queda guardado en `resultados/visor_resultados.html`.

Desde la raíz del repositorio, con R 4.3.3:

```
Rscript codigo/main.R
```

Usa R base, con 1.999 réplicas y semilla 443. El script genera el contenido de `resultados/` desde la base y puede recibir un CSV alternativo como único argumento. El lector opcional de Excel requiere `readxl`, fijado con sus dependencias en `renv.lock`.

## Resultados

- `muestra.csv`, `auditoria_*.csv`, `episodios_analizados.csv` y `sesion_R.txt` documentan la muestra, la validación y la sesión.
- `correlaciones_USD_*.csv`, `correlaciones_por_crisis.csv` y `correlacion_regional.png` muestran las correlaciones móviles y DCC en USD con y sin ajuste por factores.
- `forbes_rigobon.csv` y `resumen_forbes_rigobon.csv` informan los cambios de correlación y los valores p, con Holm por escenario.
- `descomposicion_*.csv` cuantifica el aporte contable del canal cambiario a la varianza y al comovimiento.
- `carteras_*.csv` y `carteras_fuera_de_muestra.png` documentan las estrategias, costos y desempeño fuera de muestra.

## Modificación en vivo

Para comparar 30 y 60 sesiones de crisis en Lehman:

```
Rscript codigo/defensa.R Lehman 30
Rscript codigo/defensa.R Lehman 60
```

Cada corrida conserva las 499 réplicas y usa el mismo contraste FR con factores globales. Holm se aplica a los pares del episodio elegido. Las tablas quedan en `resultados_defensa/`. Se puede agregar un CSV alternativo como tercer argumento.

## Documentación

`informe.pdf`, `bitacora_ia.md`, `referencias_E2.csv` y `contribuciones.md`.
